#!/usr/bin/env python3
"""ask.py — 프롬프트를 실제 AI에 그대로 보내고 답을 원문 그대로 남긴다 (디자인 v0.1 도구)

사용: python3 ask.py <작업폴더> [--models gpt,claude] [--force]
입력: <작업폴더>/prompt.txt — 독자가 실제로 붙여 넣을 글 그대로(예시 메모까지 채운 것)
출력: <작업폴더>/runs/<이름>.md (답 원문, 고치지 않는다) · runs/runs.json (모델·시각·토큰·비용·해시)
모델: 같은 폴더 models.json (gpt = ChatGPT 기본 모델, claude = Claude). 시스템 프롬프트 없이 새 대화 한 번.
키: OPENROUTER_API_KEY — 환경 변수 → $HERMES_HOME/ask.env → /opt/data/profiles/insta-ai/ask.env 순서로 찾는다.
    (Hermes 가 읽는 .env 가 아니라 ask.env 에 둔다 — Hermes 가 이 키로 다른 일을 하지 않게)
같은 prompt.txt 로 이미 돌린 모델은 다시 부르지 않는다(--force 면 다시). 키·답 원문은 화면에 찍지 않는다.
종료 코드: 0 통과 · 1 실행 실패 · 2 사용법·환경 오류
"""
import datetime, hashlib, json, os, pathlib, sys, urllib.error, urllib.request

HERE = pathlib.Path(__file__).resolve().parent
API = os.environ.get("ASK_API_BASE", "https://openrouter.ai/api/v1").rstrip("/")


def find_key():
    k = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if k:
        return k
    homes = [os.environ.get("HERMES_HOME"), "/opt/data/profiles/insta-ai"]
    for h in [x for x in homes if x]:
        f = pathlib.Path(h) / "ask.env"
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                if line.startswith("OPENROUTER_API_KEY="):
                    v = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if v:
                        return v
        except OSError:
            continue
    return None


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def call(key, model_id, prompt):
    body = json.dumps({"model": model_id, "messages": [{"role": "user", "content": prompt}],
                       "max_tokens": 4000, "usage": {"include": True}}).encode("utf-8")
    req = urllib.request.Request(API + "/chat/completions", data=body, method="POST", headers={
        "Authorization": "Bearer " + key, "Content-Type": "application/json",
        "HTTP-Referer": "https://aigents-ai.github.io", "X-Title": "aigents card runner"})
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            j = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
        except Exception:
            msg = ""
        raise RuntimeError(f"HTTP {e.code} {msg}".strip())
    except urllib.error.URLError as e:
        raise RuntimeError(f"연결 실패: {e.reason}")
    try:
        text = j["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise RuntimeError("답 형식이 이상해요: " + json.dumps(j, ensure_ascii=False)[:200])
    if not isinstance(text, str) or not text.strip():
        raise RuntimeError("빈 답이 왔어요")
    u = j.get("usage") or {}
    return text, {"model_used": j.get("model", model_id), "prompt_tokens": u.get("prompt_tokens"),
                  "completion_tokens": u.get("completion_tokens"), "cost_usd": u.get("cost")}


def main(argv):
    args = [a for a in argv if not a.startswith("--")]
    opts = {argv[i][2:]: (argv[i + 1] if i + 1 < len(argv) and not argv[i + 1].startswith("--") else True)
            for i in range(len(argv)) if argv[i].startswith("--")}
    if len(args) != 1:
        print(__doc__.strip().splitlines()[2]); return 2
    job = pathlib.Path(args[0]).resolve()
    pf = job / "prompt.txt"
    if not pf.is_file():
        print(f"prompt.txt 가 없어요 — {pf}"); return 2
    prompt = pf.read_text(encoding="utf-8")
    if not prompt.strip():
        print("prompt.txt 가 비었어요"); return 2
    try:
        models = json.loads((HERE / "models.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        print(f"models.json 을 읽지 못했어요 — {e}"); return 2
    want = str(opts.get("models", "gpt,claude")).split(",")
    unknown = [m for m in want if m not in models]
    if unknown:
        print("models.json 에 없는 이름: " + ", ".join(unknown)); return 2
    key = find_key()
    if not key:
        print("OPENROUTER_API_KEY 를 찾지 못했어요 — README '실행 키' 참고"); return 2

    rd = job / "runs"
    rd.mkdir(exist_ok=True)
    rp = rd / "runs.json"
    psha = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
    try:
        state = json.loads(rp.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    if state.get("prompt_sha256") != psha:
        state = {"prompt_file": "prompt.txt", "prompt_sha256": psha, "runs": {}}
    state.pop("example", None)
    done, fail = [], []
    for name in want:
        m = models[name]
        out = rd / f"{name}.md"
        if not opts.get("force") and name in state["runs"] and out.is_file():
            done.append(f"{name}(이미 있음)"); continue
        try:
            text, info = call(key, m["id"], prompt)
        except RuntimeError as e:
            fail.append(f"{name}: {e}"); continue
        out.write_text(text, encoding="utf-8")
        state["runs"][name] = dict({"id": m["id"], "label": m["label"], "short": m.get("short", m["label"]),
                                    "at": now(), "output_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}, **info)
        done.append(f"{name}({m['label']}, {len(text)}자)")
    rp.write_text(json.dumps(state, ensure_ascii=False, indent=1), encoding="utf-8")
    cost = sum((r.get("cost_usd") or 0) for r in state["runs"].values())
    print(("실행 통과" if not fail else "실행 실패") + " — " + (" · ".join(done) or "새로 받은 답 없음") +
          (f" · 비용 합계 약 ${cost:.4f}" if cost else "") + ("" if not fail else "\n실패: " + " / ".join(fail)))
    return 0 if not fail else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

#!/usr/bin/env node
/* render.js — 디자인 v0 렌더기 (인스타 AI 계정 카드뉴스, 1080×1350 JPEG)
 *
 *  node render.js <작업폴더>             deck.json → slides/01.jpg… + meta.json(slides) + render.json
 *  node render.js --grid <캡처> [출력]    강조 위치(mark) 고르기용 격자 그림 (기본 /tmp/grid-<이름>.jpg)
 *  node render.js --selftest             example/ 을 임시 폴더에 렌더해 환경을 점검
 *
 * 통과: 종료 코드 0 · 검사 실패: 1 (slides/ 는 건드리지 않고 render.json 에 이유) · 사용법·환경 오류: 2
 * 이 파일은 원본이라 직원은 고치지 않는다. 고칠 점은 '개선 후보'로 제안한다.
 */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { pathToFileURL } = require('url');

const HERE = __dirname;
const VERSION = 'design-v0 render.js 1.2';
const SLIDE_W = 1080, SLIDE_H = 1350, SAFE = 72, BODY_BOTTOM = 190;
const CTA = '아무 댓글이나 남기면';
const URL_TEXT = 'aigents-ai.github.io';
const PROMISE = '@aigents_ai · 매주 업무 시간을 줄여 주는 AI 사용법';

// ───────── 환경 ─────────
function loadPlaywright() {
  const data = process.env.HERMES_HOME || '/opt/data';
  const tries = ['playwright', 'playwright-core', '/opt/hermes/node_modules/playwright', '/opt/hermes/node_modules/playwright-core',
    path.join(data, 'tools/node_modules/playwright'), path.join(data, 'tools/node_modules/playwright-core')];
  for (const t of tries) { try { return { pw: require(t), from: t }; } catch (e) { /* 다음 후보 */ } }
  return null;
}
function findChromium() {
  try { const p = fs.readFileSync('/etc/hermes/chromium-executable-path', 'utf8').trim(); if (p && fs.existsSync(p)) return p; } catch (e) { /* Hermes 이미지가 아님 */ }
  const roots = [process.env.PLAYWRIGHT_BROWSERS_PATH, '/opt/hermes/.playwright', path.join(os.homedir(), '.cache', 'ms-playwright')].filter(Boolean);
  const rel = ['chrome-headless-shell-linux64/chrome-headless-shell', 'chrome-linux/headless_shell', 'chrome-linux64/chrome', 'chrome-linux/chrome'];
  for (const r of roots) {
    let ds = [];
    try { ds = fs.readdirSync(r).filter(d => /^chromium/.test(d)).sort().reverse(); } catch (e) { continue; }
    for (const d of ds) for (const x of rel) { const p = path.join(r, d, x); if (fs.existsSync(p)) return p; }
  }
  for (const p of ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome']) if (fs.existsSync(p)) return p;
  return null;
}
async function launch() {
  const lp = loadPlaywright();
  if (!lp) throw new EnvError('playwright 모듈을 찾지 못했어요 — README의 "환경과 점검"대로 /opt/data/tools 에 playwright-core 를 설치하세요');
  const args = ['--disable-dev-shm-usage'];
  try { return await lp.pw.chromium.launch({ args }); }
  catch (e) {
    const exe = findChromium();
    if (!exe) throw new EnvError('크로미움을 찾지 못했어요 — ' + String(e.message).split('\n')[0]);
    return await lp.pw.chromium.launch({ args, executablePath: exe });
  }
}
class EnvError extends Error {}

// ───────── 글 → HTML ─────────
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const br = s => esc(s).replace(/\n/g, '<br>');
function withEm(text, em) {
  let h = esc(text);
  if (em) { const e = esc(em); const i = h.indexOf(e); if (i >= 0) h = h.slice(0, i) + '<em>' + e + '</em>' + h.slice(i + e.length); }
  return h.replace(/\n/g, '<br>');
}
const promptHtml = s => esc(s.replace(/\s+$/, '')).replace(/\[[^\]\n]+\]/g, m => '<mark>' + m + '</mark>');
const oneLine = v => String(v || '').replace(/\s*\n\s*/g, ' ').trim();
function localTime() {
  const d = new Date(), z = -d.getTimezoneOffset(), p = v => String(Math.floor(Math.abs(v))).padStart(2, '0');
  return new Date(d.getTime() + z * 60000).toISOString().slice(0, 19) + (z >= 0 ? '+' : '-') + p(z / 60) + ':' + p(z % 60);
}

// ───────── 검사 1: deck.json ─────────
function validate(deck, job) {
  const E = [], W = [];
  const isStr = v => typeof v === 'string' && v.trim().length > 0;
  const root = path.resolve(job) + path.sep;
  const shotOk = rel => { if (!isStr(rel)) return false; const p = path.resolve(job, rel); return p.startsWith(root) && /\.(png|jpe?g|webp)$/i.test(p) && fs.existsSync(p); };
  const rect = v => Array.isArray(v) && v.length === 4 && v.every(x => typeof x === 'number' && x >= 0 && x <= 100) && v[0] < v[2] && v[1] < v[3];
  if (!/^\d{3}$/.test(deck.no || '')) E.push('no: 자료실 번호 세 자리 문자열(예: "001")');
  if (!isStr(deck.topic) || deck.topic.length > 12) E.push('topic: 주제 이름 1~12자(예: "회의록")');
  const t = deck.tested || {};
  if (!/^\d{4}[.-]\d{2}[.-]\d{2}$/.test(t.date || '')) E.push('tested.date: 직접 해 본 날짜, "2026-10-29" 형식');
  if (!isStr(t.device)) E.push('tested.device: 기준 기기(예: "휴대폰 앱", "PC 웹")');
  const S = Array.isArray(deck.slides) ? deck.slides : [];
  if (!S.length) E.push('slides: 장 목록이 비었어요');
  else {
    if (S[0].type !== 'cover') E.push('1장은 cover(표지)여야 해요');
    if (S[S.length - 1].type !== 'end') E.push('마지막 장은 end(마무리)여야 해요');
    if (S.length !== 6) W.push(`장 수 ${S.length}장 — 이 계정 기준은 6장(check_card.py)`);
  }
  S.forEach((s, i) => {
    const at = `${i + 1}장(${s && s.type})`;
    if (!s || typeof s !== 'object') { E.push(`${at}: 형식 오류`); return; }
    if (s.step != null && !(Number.isInteger(s.step) && s.step > 0 && s.step < 10)) E.push(`${at}: step — 단계 번호 1~9`);
    switch (s.type) {
      case 'cover':
        if (!shotOk(s.bg)) E.push(`${at}: bg — 작업 폴더 안 캡처 파일(png·jpg) 경로`);
        if (!Array.isArray(s.lines) || s.lines.length < 1 || s.lines.length > 2 || !s.lines.every(isStr)) E.push(`${at}: lines — 크림 자막 1~2줄(상황)`);
        if (!isStr(s.hit)) E.push(`${at}: hit — 주황 자막 1줄(해결)`);
        if (s.pos != null && !['mid', 'lower'].includes(s.pos)) E.push(`${at}: pos — "mid" 또는 "lower"`);
        if (s.tone != null && !['dark', 'light'].includes(s.tone)) E.push(`${at}: tone — "dark" 또는 "light"`);
        if (s.bg_pos != null && !/^\d{1,3}% \d{1,3}%$/.test(s.bg_pos)) E.push(`${at}: bg_pos — "50% 30%" 형식`);
        break;
      case 'step': case 'result':
        if (s.type === 'step' && s.step == null) E.push(`${at}: step — 단계 번호`);
        if (!isStr(s.title)) E.push(`${at}: title — 제목`);
        if (!shotOk(s.shot)) E.push(`${at}: shot — 작업 폴더 안 캡처 파일(png·jpg) 경로`);
        if (s.mark != null && !rect(s.mark)) E.push(`${at}: mark — [x0, y0, x1, y1] 0~100(%)`);
        if (s.focus != null && !(typeof s.focus === 'number' && s.focus >= 0 && s.focus <= 100)) E.push(`${at}: focus — 0~100(%)`);
        if (s.path != null && (!Array.isArray(s.path) || s.path.length < 1 || s.path.length > 4 || !s.path.every(isStr))) E.push(`${at}: path — 글 1~4개 목록`);
        if (s.type === 'step' && !s.mark) W.push(`${at}: mark 없음 — 어디를 누르는지 강조하면 따라 하기 쉬워요`);
        break;
      case 'prompt':
        if (!isStr(s.title)) E.push(`${at}: title — 제목`);
        if (!isStr(s.prompt)) E.push(`${at}: prompt — 프롬프트 본문`);
        else if (!/\[[^\]\n]+\]/.test(s.prompt)) W.push(`${at}: prompt 에 [바꿀 곳] 표시가 없어요`);
        break;
      case 'end':
        if (!Array.isArray(s.lines) || s.lines.length < 1 || s.lines.length > 3 || !s.lines.every(isStr)) E.push(`${at}: lines — 큰 글 1~3줄`);
        if (!isStr(s.dm)) E.push(`${at}: dm — DM으로 받는 것(예: "전체 프롬프트 3개를 DM으로 보내 드려요")`);
        break;
      default: E.push(`${at}: type 은 cover·step·prompt·result·end 중 하나`);
    }
  });
  S.forEach((s, i) => {
    if (!s || typeof s !== 'object') return;
    const vals = ['title', 'desc', 'hit', 'prompt', 'hint', 'more', 'dm', 'cue', 'em', 'label'].map(k => s[k]).concat(Array.isArray(s.lines) ? s.lines : [], Array.isArray(s.path) ? s.path : []);
    for (const v of vals) if (typeof v === 'string' && /\p{Extended_Pictographic}/u.test(v)) E.push(`${i + 1}장: 이모지는 쓰지 않아요(글꼴에 없어 서버마다 다르게 보임) — "${v.slice(0, 16)}"`);
  });
  if (deck.masks != null) {
    if (typeof deck.masks !== 'object' || Array.isArray(deck.masks)) E.push('masks: {"shots/01.png": [[x0, y0, x1, y1], …]} 형식');
    else for (const [k, v] of Object.entries(deck.masks)) {
      if (!shotOk(k)) E.push(`masks: ${k} — 작업 폴더 안 캡처 파일이 아니에요`);
      if (!Array.isArray(v) || !v.length || !v.every(rect)) E.push(`masks: ${k} — [[x0, y0, x1, y1], …] 0~100(%)`);
    }
  }
  return { E, W };
}

// ───────── 장 만들기 ─────────
function buildHtml(deck, imgUrl) {
  const d = deck, t = Object.assign({}, d.tested, { date: d.tested.date.replace(/-/g, '.') });  // 그림에는 2026.10.29 로 표시
  const chip = `<div class="chip"><span class="b"><span class="cm">ai<i></i></span>AI 자료실</span><span>No.${esc(d.no)}</span></div>`;
  const pill = (s, dflt) => `<span class="pill">${esc(s.label || (s.step ? 'STEP ' + s.step : dflt))}</span>`;
  const top = (s, dflt) => `<div class="top">${pill(s, dflt)}<span class="meta">No.${esc(d.no)} · ${esc(d.topic)}</span></div>`;
  const frame = (s, min) => `<div class="frame" data-min="${min}"${s.mark ? ` data-mark="${esc(JSON.stringify(s.mark))}"` : ''}${s.focus != null ? ` data-focus="${+s.focus}"` : ''}${s.step ? ` data-n="${+s.step}"` : ''}><img src="${imgUrl(s.shot)}" alt=""><span class="hl"><b></b></span></div>`;
  const out = d.slides.map(s => {
    switch (s.type) {
      case 'cover': return `<section class="slide cover${s.tone === 'light' ? ' light' : ''}">
  <div class="bg deco"><img src="${imgUrl(s.bg)}" style="object-position:${esc(s.bg_pos || '50% 30%')}" alt=""></div>
  <div class="dim deco"></div>
  ${chip}
  <div class="caps ${s.pos === 'lower' ? 'lower' : 'mid'}">${s.lines.map(l => `<span class="one">${esc(l)}</span>`).join('')}<span class="one k">${esc(s.hit)}</span></div>
  <p class="cue one">${esc(s.cue || '실제 화면으로 따라 하기')}</p>
</section>`;
      case 'step': return `<section class="slide body step">
  ${top(s, 'STEP')}
  <h2 class="ttl" data-max-lines="2">${withEm(s.title, s.em)}</h2>
  ${s.desc ? `<p class="desc" data-max-lines="2">${br(s.desc)}</p>` : ''}
  ${frame(s, 400)}
  ${s.path ? `<div class="path">${s.path.map(p => `<span class="one">${esc(p)}</span>`).join('<i>→</i>')}</div>` : ''}
  <p class="foot">실제 화면 · ${esc(t.date)} · ${esc(t.device)} 기준</p>
</section>`;
      case 'result': return `<section class="slide body result">
  ${top(s, '결과')}
  <h2 class="ttl" data-max-lines="2">${withEm(s.title, s.em)}</h2>
  ${s.desc ? `<p class="desc" data-max-lines="2">${br(s.desc)}</p>` : ''}
  ${frame(s, 460)}
  <p class="foot">실제 결과 · ${esc(t.date)} · ${esc(t.device)} 기준</p>
</section>`;
      case 'prompt': return `<section class="slide body prompt">
  ${top(s, '프롬프트')}
  <h2 class="ttl" data-max-lines="2">${withEm(s.title, s.em)}</h2>
  <div class="code"><div class="ch"><b>프롬프트</b><span>길게 눌러 복사</span></div><p>${promptHtml(s.prompt)}</p></div>
  ${s.hint || s.more ? `<div class="hint">${s.hint ? `<b class="one">${esc(s.hint)}</b>` : ''}${s.more ? `<span class="one">${esc(s.more)}</span>` : ''}</div>` : ''}
  <p class="foot">직접 해 본 기준 · ${esc(t.date)} · ${esc(t.device)}</p>
</section>`;
      case 'end': return `<section class="slide end">
  <div class="top"><div class="brand"><span class="bm">ai<i></i></span>AI 자료실</div><span class="no">No.${esc(d.no)}</span></div>
  <h2 class="ttl" data-max-lines="${s.lines.length}">${s.lines.map(esc).join('<br>')}</h2>
  <div class="bubble"><p class="l1 one"><em>아무 댓글</em>이나 남기면</p><p class="l2 one">${esc(s.dm)}</p></div>
  <div class="eb"><div class="r1"><span class="one">DM이 안 오면 자료실에서 No.${esc(d.no)}</span><span class="url">${URL_TEXT}</span></div><p class="r2">${esc(PROMISE)}</p></div>
</section>`;
    }
  }).join('\n');
  return `<!doctype html><html lang="ko"><head><meta charset="utf-8"><base href="${pathToFileURL(HERE + path.sep).href}"><link rel="stylesheet" href="cards.css"></head><body>\n${out}\n</body></html>`;
}

// 메타(check_card.py 가 읽는 장별 제목·본문) — 렌더된 글과 같게 렌더기가 쓴다
function metaSlides(deck) {
  return deck.slides.map(s => Object.assign({ kind: s.type }, metaOne(s)));
}
function metaOne(s) {
  switch (s.type) {
    case 'cover': return { type: 'cover', title: s.lines.join(' '), body: s.hit };
    case 'step': return { type: 'step', title: oneLine(s.title), body: oneLine(s.desc), note: (s.path || []).join(' → ') };
    case 'result': return { type: 'result', title: oneLine(s.title), body: oneLine(s.desc) };
    case 'prompt': return { type: 'prompt', title: oneLine(s.title), body: s.prompt.trim(), note: [s.hint, s.more].filter(Boolean).join(' / ') };
    case 'end': return { type: 'end', title: s.lines.join(' '), body: `${CTA} ${s.dm}` };
  }
}

// ───────── 페이지 안에서 도는 코드 ─────────
function pageLayout() {
  const probs = [];
  document.querySelectorAll('.frame').forEach(fr => {
    const img = fr.querySelector('img'), hl = fr.querySelector('.hl');
    const W = fr.clientWidth, H = fr.clientHeight, nw = img.naturalWidth, nh = img.naturalHeight;
    if (!nw || !W || !H) return;
    const ih = nh * W / nw;
    img.style.width = W + 'px'; img.style.height = ih + 'px';
    const mk = fr.dataset.mark ? JSON.parse(fr.dataset.mark) : null;
    let off = 0;
    if (ih <= H) off = (H - ih) / 2;
    else if (fr.dataset.focus || mk) {
      const cy = fr.dataset.focus ? +fr.dataset.focus / 100 * ih : (mk[1] + mk[3]) / 200 * ih;
      off = -Math.min(Math.max(cy - H / 2, 0), ih - H);
    }
    img.style.top = off + 'px';
    if (!mk) return;
    const pad = 14;
    let x0 = mk[0] / 100 * W, x1 = mk[2] / 100 * W, y0 = mk[1] / 100 * ih + off, y1 = mk[3] / 100 * ih + off;
    if (y1 < pad + 20 || y0 > H - pad - 20) { const n = [...document.querySelectorAll('.slide')].indexOf(fr.closest('.slide')) + 1; probs.push(`${n}장: 강조 위치(mark)가 화면 틀 밖이에요 — focus 를 지우거나 mark 를 확인하세요`); return; }
    x0 = Math.max(x0, pad); y0 = Math.max(y0, pad); x1 = Math.min(x1, W - pad); y1 = Math.min(y1, H - pad);
    Object.assign(hl.style, { display: 'block', left: x0 + 'px', top: y0 + 'px', width: (x1 - x0) + 'px', height: (y1 - y0) + 'px' });
    const b = hl.querySelector('b');
    if (fr.dataset.n) { b.textContent = fr.dataset.n; b.style.left = (Math.max(x0 - 46, 10) - x0) + 'px'; b.style.top = (Math.max(y0 - 46, 10) - y0) + 'px'; }
    else b.remove();
  });
  return probs;
}
// 프롬프트 장: 글이 길면 프롬프트 글씨를 35px → 28px 까지 한 단계씩 줄여 맞춘다(check_card 의 프롬프트 180자 기준에 맞춤)
function pageFitPrompts(arg) {
  const { SLIDE_H, BODY_BOTTOM } = arg, steps = [[35, 1.75], [33, 1.72], [31, 1.68], [29, 1.64], [28, 1.6]], used = [];
  document.querySelectorAll('.slide.prompt').forEach(s => {
    const p = s.querySelector('.code p'), lim = s.getBoundingClientRect().top + SLIDE_H - BODY_BOTTOM;
    const over = () => [...s.children].some(c => !c.classList.contains('foot') && c.getBoundingClientRect().bottom > lim + 2);
    for (const [fs, lh] of steps) { p.style.fontSize = fs + 'px'; p.style.lineHeight = String(lh); if (!over()) break; }
    used.push(parseFloat(p.style.fontSize));
  });
  return used;
}
function pageChecks(arg) {
  const { SAFE, SLIDE_H, BODY_BOTTOM, fonts } = arg;
  const errs = [];
  const lines = e => { const rg = document.createRange(); rg.selectNodeContents(e); const tops = [...rg.getClientRects()].filter(q => q.width > 1).map(q => q.top).sort((a, b) => a - b); let n = 0, last = -1e9; for (const t of tops) { if (t - last > 10) { n++; last = t; } } return n; };
  const deco = e => e && e.closest('.deco,.frame');
  document.querySelectorAll('.slide').forEach((s, i) => {
    const n = i + 1, r = s.getBoundingClientRect(), cut = v => v.replace(/\s+/g, ' ').trim().slice(0, 18);
    s.querySelectorAll('.one').forEach(e => { if (lines(e) > 1) errs.push(`${n}장: 한 줄에 안 들어가요 — "${cut(e.textContent)}"`); });
    s.querySelectorAll('[data-max-lines]').forEach(e => { const L = lines(e); if (L > +e.dataset.maxLines) errs.push(`${n}장: ${L}줄이에요(최대 ${e.dataset.maxLines}줄) — "${cut(e.textContent)}"`); });
    [...s.querySelectorAll('*')].filter(e => !deco(e)).forEach(e => { const q = e.getBoundingClientRect(); if (q.width && (q.right > r.right + 1 || q.bottom > r.bottom + 1 || q.left < r.left - 1 || q.top < r.top - 1)) errs.push(`${n}장: 장 밖으로 나가요 — ${e.className || e.tagName}`); });
    const tw = document.createTreeWalker(s, NodeFilter.SHOW_TEXT); let t;
    while ((t = tw.nextNode())) {
      if (!t.textContent.trim() || deco(t.parentElement)) continue;
      const rg = document.createRange(); rg.selectNodeContents(t);
      for (const q of rg.getClientRects()) if (q.width && (q.left < r.left + SAFE - 1 || q.right > r.right - SAFE + 1)) { errs.push(`${n}장: 글자가 좌우 여백(${SAFE}px) 밖이에요 — "${cut(t.textContent)}"`); break; }
    }
    s.querySelectorAll('.frame').forEach(f => { if (f.clientHeight < +f.dataset.min) errs.push(`${n}장: 글이 길어 화면 틀이 ${f.clientHeight}px로 작아졌어요(최소 ${f.dataset.min}px) — 제목·설명을 줄이세요`); });
    if (s.classList.contains('body')) {
      const lim = r.top + SLIDE_H - BODY_BOTTOM + 2;
      if ([...s.children].some(c => !c.classList.contains('foot') && c.getBoundingClientRect().bottom > lim)) errs.push(`${n}장: 내용이 길어 아래 출처 줄과 겹쳐요 — ${s.classList.contains('prompt') ? '프롬프트나 아래 안내' : '제목·설명·경로'}를 줄이세요`);
    }
    if (s.classList.contains('cover')) {
      const caps = s.querySelector('.caps').getBoundingClientRect(), cue = s.querySelector('.cue').getBoundingClientRect(), chip = s.querySelector('.chip').getBoundingClientRect();
      if (caps.bottom > cue.top - 30) errs.push(`${n}장: 자막이 아래 문구와 겹쳐요 — 줄 수를 줄이거나 pos 를 바꾸세요`);
      if (caps.top < chip.bottom + 40) errs.push(`${n}장: 자막이 위 번호와 겹쳐요 — 줄 수를 줄이거나 pos 를 바꾸세요`);
    }
    if (s.classList.contains('end')) {
      const bb = s.querySelector('.bubble').getBoundingClientRect(), eb = s.querySelector('.eb').getBoundingClientRect();
      if (bb.bottom + 34 > eb.top - 24) errs.push(`${n}장: 말풍선이 아래 안내와 겹쳐요 — 큰 글을 줄이세요`);
    }
  });
  document.querySelectorAll('img').forEach(im => { if (!im.complete || !im.naturalWidth) errs.push(`캡처를 못 읽었어요 — ${decodeURIComponent(im.src.split('/').pop())}`); });
  const loaded = new Set([...document.fonts].filter(f => f.status === 'loaded').map(f => f.family.replace(/["']/g, '') + ':' + f.weight));
  for (const k of fonts) if (!loaded.has(k)) errs.push(`글꼴이 불러와지지 않았어요 — ${k} (templates/fonts 확인)`);
  return errs;
}

// ───────── 렌더 ─────────
async function prepareImages(browser, deck, job, tmp) {
  const map = {};
  let i = 0;
  for (const [rel, rects] of Object.entries(deck.masks || {})) {
    const src = path.resolve(job, rel), out = path.join(tmp, `masked-${++i}.png`), page = path.join(tmp, `mask-${i}.html`);
    fs.writeFileSync(page, `<!doctype html><html><body style="margin:0"><div id="w" style="position:relative;display:inline-block"><img src="${pathToFileURL(src).href}" style="display:block">${rects.map(r => `<div style="position:absolute;left:${r[0]}%;top:${r[1]}%;width:${r[2] - r[0]}%;height:${r[3] - r[1]}%;background:#d6d3ce;border-radius:10px"></div>`).join('')}</div></body></html>`);
    const p = await browser.newPage({ viewport: { width: 1200, height: 1200 }, deviceScaleFactor: 1 });
    await p.goto(pathToFileURL(page).href, { waitUntil: 'load' });
    await (await p.$('#w')).screenshot({ path: out });
    await p.close();
    map[path.resolve(job, rel)] = out;
  }
  return rel => pathToFileURL(map[path.resolve(job, rel)] || path.resolve(job, rel)).href;
}

async function render(job, opts = {}) {
  job = path.resolve(job);
  const rel = path.relative(HERE, job);
  if (!opts.allowInside && (rel === '' || !rel.startsWith('..'))) throw new EnvError('템플릿 폴더 안에서는 렌더하지 않아요 — 작업 폴더(outbox/pending/<ID>)를 주세요');
  const deckPath = path.join(job, 'deck.json');
  let deck;
  try { deck = JSON.parse(fs.readFileSync(deckPath, 'utf8')); }
  catch (e) { throw new EnvError(`deck.json 을 읽지 못했어요 — ${e.code === 'ENOENT' ? '파일 없음' : e.message.split('\n')[0]}`); }
  const result = { ok: false, renderer: VERSION, rendered_at: localTime(), slides: 0, errors: [], warnings: [] };
  const { E, W } = validate(deck, job);
  result.warnings.push(...W);
  if (E.length) { result.errors = E; fs.writeFileSync(path.join(job, 'render.json'), JSON.stringify(result, null, 1)); return result; }

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'render-'));
  const browser = await launch();
  try {
    result.chromium = browser.version();
    const imgUrl = await prepareImages(browser, deck, job, tmp);
    const htmlPath = path.join(tmp, 'deck.html');
    fs.writeFileSync(htmlPath, buildHtml(deck, imgUrl));
    const page = await browser.newPage({ viewport: { width: SLIDE_W, height: SLIDE_H }, deviceScaleFactor: 1 });
    await page.goto(pathToFileURL(htmlPath).href, { waitUntil: 'load' });
    await page.evaluate(() => document.fonts.ready);
    await page.evaluate(() => Promise.all([...document.images].map(i => i.complete ? 0 : new Promise(r => { i.onload = i.onerror = r; }))));
    const fonts = ['SUIT:400', 'SUIT:700', 'SUIT:800', 'SUIT:900'].concat(deck.slides.some(s => s.type === 'prompt') ? ['Code:400'] : []);
    const promptSizes = await page.evaluate(pageFitPrompts, { SLIDE_H, BODY_BOTTOM });
    if (promptSizes.some(v => v < 35)) result.warnings.push(`프롬프트가 길어 글씨를 ${Math.min(...promptSizes)}px로 줄였어요`);
    const layoutProblems = await page.evaluate(pageLayout);
    const errs = layoutProblems.concat(await page.evaluate(pageChecks, { SAFE, SLIDE_H, BODY_BOTTOM, fonts }));
    result.errors = [...new Set(errs)];
    const slides = await page.$$('.slide');
    const outDir = result.errors.length ? path.join(os.tmpdir(), `render-preview-${deck.no}`) : path.join(job, 'slides');
    fs.mkdirSync(outDir, { recursive: true });
    for (const f of fs.readdirSync(outDir)) if (/^\d{2}\.jpg$/.test(f)) fs.unlinkSync(path.join(outDir, f));
    for (let i = 0; i < slides.length; i++) await slides[i].screenshot({ path: path.join(outDir, String(i + 1).padStart(2, '0') + '.jpg'), type: 'jpeg', quality: 90 });
    result.slides = slides.length;
    if (result.errors.length) result.preview = outDir;
    else {
      const metaPath = path.join(job, 'meta.json');
      let meta = {};
      try { meta = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch (e) { /* 새로 만든다 */ }
      meta.slides = metaSlides(deck);
      if (!meta.code) meta.code = deck.no;
      // 직접 해 본 기록: 그림 아래 줄과 같은 값을 meta 에도 (날짜는 check_card.py 형식 YYYY-MM-DD)
      const tt = deck.tested, keep = {};
      for (const k of ['app', 'plan', 'scope']) if (typeof tt[k] === 'string' && tt[k].trim()) keep[k] = tt[k];
      meta.tested = Object.assign({}, meta.tested || {}, { date: tt.date.replace(/\./g, '-'), device: tt.device }, keep);
      fs.writeFileSync(metaPath, JSON.stringify(meta, null, 1));
      result.ok = true;
    }
  } finally {
    await browser.close();
    fs.rmSync(tmp, { recursive: true, force: true });
  }
  fs.writeFileSync(path.join(job, 'render.json'), JSON.stringify(result, null, 1));
  return result;
}

// ───────── 격자 그림 ─────────
async function grid(img, out) {
  img = path.resolve(img);
  if (!fs.existsSync(img)) throw new EnvError(`캡처 파일이 없어요 — ${img}`);
  out = path.resolve(out || path.join(os.tmpdir(), `grid-${path.basename(img).replace(/\.[^.]+$/, '')}.jpg`));
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'grid-'));
  const page = path.join(tmp, 'grid.html');
  fs.writeFileSync(page, `<!doctype html><html><head><base href="${pathToFileURL(HERE + path.sep).href}"><link rel="stylesheet" href="cards.css"></head><body style="margin:0;background:#fff">
<div id="w" style="position:relative;display:inline-block"><img id="i" src="${pathToFileURL(img).href}" style="display:block"></div>
<script>
const i = document.getElementById('i'), w = document.getElementById('w');
function draw() {
  i.style.width = (i.naturalWidth >= i.naturalHeight ? 1400 : 900) + 'px';
  for (let k = 5; k < 100; k += 5) {
    const major = k % 10 === 0, c = major ? 'rgba(230,0,90,.85)' : 'rgba(230,0,90,.32)', sz = major ? 2 : 1;
    const v = document.createElement('div'); v.style.cssText = 'position:absolute;top:0;bottom:0;left:' + k + '%;width:' + sz + 'px;background:' + c; w.appendChild(v);
    const h = document.createElement('div'); h.style.cssText = 'position:absolute;left:0;right:0;top:' + k + '%;height:' + sz + 'px;background:' + c; w.appendChild(h);
    if (major) for (const [css, txt] of [['left:' + k + '%;top:4px', 'x' + k], ['left:' + k + '%;bottom:4px', 'x' + k], ['top:' + k + '%;left:4px', 'y' + k], ['top:' + k + '%;right:4px', 'y' + k]]) {
      const l = document.createElement('span'); l.textContent = txt; l.style.cssText = 'position:absolute;' + css + ';transform:translate(' + (css.startsWith('left') ? '-50%' : '0') + ',' + (css.startsWith('top') ? '-50%' : '0') + ');padding:1px 6px;border-radius:6px;background:#fff;color:#c4004d;font:800 18px SUIT,sans-serif;border:1px solid #c4004d';
      w.appendChild(l);
    }
  }
  document.title = 'ready';
}
i.complete ? draw() : (i.onload = draw);
</script></body></html>`);
  const browser = await launch();
  try {
    const p = await browser.newPage({ viewport: { width: 1500, height: 1200 }, deviceScaleFactor: 1 });
    await p.goto(pathToFileURL(page).href, { waitUntil: 'load' });
    await p.waitForFunction(() => document.title === 'ready');
    await (await p.$('#w')).screenshot({ path: out, type: 'jpeg', quality: 85 });
  } finally { await browser.close(); fs.rmSync(tmp, { recursive: true, force: true }); }
  return out;
}

// ───────── 자체 시험 ─────────
async function selftest() {
  const ex = path.join(HERE, 'example');
  const job = fs.mkdtempSync(path.join(os.tmpdir(), 'render-selftest-'));
  copyDir(ex, job, name => name === 'slides');
  const r = await render(job, { allowInside: false });
  const sizes = r.ok ? fs.readdirSync(path.join(job, 'slides')).map(f => jpegSize(path.join(job, 'slides', f))) : [];
  const sizeOk = sizes.length === 6 && sizes.every(s => s && s[0] === SLIDE_W && s[1] === SLIDE_H);
  return { r, job, sizeOk };
}
function copyDir(src, dst, skip) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    if (skip(e.name)) continue;
    const a = path.join(src, e.name), b = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(a, b, skip); else fs.copyFileSync(a, b);
  }
}
function jpegSize(p) {
  const b = fs.readFileSync(p); if (b[0] !== 0xff || b[1] !== 0xd8) return null;
  let i = 2;
  while (i + 9 < b.length) {
    if (b[i] !== 0xff) { i++; continue; }
    const m = b[i + 1];
    if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(m)) return [b.readUInt16BE(i + 7), b.readUInt16BE(i + 5)];
    if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) { i += 2; continue; }
    i += 2 + b.readUInt16BE(i + 2);
  }
  return null;
}

// ───────── 실행 ─────────
function envReport() {
  const lp = loadPlaywright();
  return [`node ${process.version}`, `playwright: ${lp ? lp.from : '없음'}`, `PLAYWRIGHT_BROWSERS_PATH=${process.env.PLAYWRIGHT_BROWSERS_PATH || '(없음)'}`, `크로미움 후보: ${findChromium() || '없음'}`].join(' · ');
}
async function main() {
  const a = process.argv.slice(2);
  if (!a.length || a[0] === '--help' || a[0] === '-h') { console.log(fs.readFileSync(__filename, 'utf8').split('\n').slice(1, 10).join('\n')); return 2; }
  if (a[0] === '--version') { console.log(VERSION); return 0; }
  if (a[0] === '--grid') { if (!a[1]) { console.log('사용: node render.js --grid <캡처> [출력.jpg]'); return 2; } console.log('격자 그림: ' + await grid(a[1], a[2])); return 0; }
  if (a[0] === '--selftest') {
    const { r, job, sizeOk } = await selftest();
    if (r.ok && sizeOk) { console.log(`자체 시험 통과 — ${r.slides}장 1080×1350 · ${r.chromium} · ${VERSION}\n결과: ${job}/slides`); return 0; }
    console.log(`자체 시험 실패 — ${r.errors.join(' / ') || '크기 확인 실패'}\n${envReport()}`); return 1;
  }
  const r = await render(a[0]);
  const w = r.warnings.length ? ` (경고 ${r.warnings.length}: ${r.warnings.join(' / ')})` : '';
  if (r.ok) { console.log(`렌더 통과 — ${r.slides}장 → ${path.join(path.resolve(a[0]), 'slides')}${w}`); return 0; }
  console.log(`렌더 실패 — 오류 ${r.errors.length}: ${r.errors.join(' / ')}${w}${r.preview ? `\n미리보기(검사 실패본): ${r.preview}` : ''}`);
  return 1;
}
main().then(c => process.exit(c), e => { console.log(`렌더기 오류 — ${e.message}${e instanceof EnvError ? '' : '\n' + e.stack}\n${envReport()}`); process.exit(2); });

#!/usr/bin/env node
/* render.js — 디자인 v0.1 렌더기 (인스타 AI 계정 카드뉴스, 1080×1350 JPEG)
 *
 *  node render.js <작업폴더>             deck.json → slides/01.jpg… + meta.json(slides·tested) + render.json
 *  node render.js --grid <캡처> [출력]    강조 위치(mark) 고르기용 격자 그림 (기본 /tmp/grid-<이름>.jpg)
 *  node render.js --import <원본> <이름> --app <앱> --device <기기> --date <YYYY-MM-DD>
 *                                         대표가 찍은 화면을 화면 모음(library)에 JPEG로 넣고 index.json 에 등록
 *  node render.js --selftest             example/ 을 임시 폴더에 렌더해 환경을 점검
 *
 * 통과: 종료 코드 0 · 검사 실패: 1 (slides/ 는 건드리지 않고 render.json 에 이유) · 사용법·환경 오류: 2
 * 이 파일은 원본이라 직원은 고치지 않는다. 고칠 점은 '개선 후보'로 제안한다.
 */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { pathToFileURL } = require('url');

const HERE = __dirname;
const VERSION = 'design-v0.1 render.js 2.0';
const LIB_DEFAULT = process.env.CARD_LIBRARY || path.resolve(__dirname, '..', 'library');  // work/brand/ai/library
const SLIDE_W = 1080, SLIDE_H = 1350, SAFE = 72, BODY_BOTTOM = 190;
const CTA = '아무 댓글이나 남기면';
const URL_TEXT = 'aigents-ai.github.io';
const PROMISE = '@aigents_ai · 매주 업무 시간을 줄여 주는 AI 사용법';

// ───────── 환경 ─────────
function loadPlaywright() {
  const data = process.env.HERMES_HOME || '/opt/data';
  const tries = ['playwright', 'playwright-core', '/opt/hermes/node_modules/playwright', '/opt/hermes/node_modules/playwright-core',
    path.join(data, 'tools/node_modules/playwright'), path.join(data, 'tools/node_modules/playwright-core'),
    '/opt/data/tools/node_modules/playwright', '/opt/data/tools/node_modules/playwright-core'];
  for (const t of tries) { try { return { pw: require(t), from: t }; } catch (e) { /* 다음 후보 */ } }
  return null;
}
function findChromium() {
  try { const p = fs.readFileSync('/etc/hermes/chromium-executable-path', 'utf8').trim(); if (p && fs.existsSync(p)) return p; } catch (e) { /* Hermes 이미지가 아님 */ }
  const roots = [process.env.PLAYWRIGHT_BROWSERS_PATH, '/opt/hermes/.playwright', path.join(os.homedir(), '.cache', 'ms-playwright')].filter(Boolean);
  const rel = ['chrome-headless-shell-linux64/chrome-headless-shell', 'chrome-linux/headless_shell', 'chrome-linux64/chrome', 'chrome-linux/chrome'];
  for (const r of roots) {
    let ds = [];
    try { ds = fs.readdirSync(r).filter(d => /^chromium/.test(d)).sort().reverse(); } catch (e) { continue; }
    for (const d of ds) for (const x of rel) { const p = path.join(r, d, x); if (fs.existsSync(p)) return p; }
  }
  for (const p of ['/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome']) if (fs.existsSync(p)) return p;
  return null;
}
async function launch() {
  const lp = loadPlaywright();
  if (!lp) throw new EnvError('playwright 모듈을 찾지 못했어요 — README의 "환경과 점검"대로 /opt/data/tools 에 playwright-core 를 설치하세요');
  const args = ['--disable-dev-shm-usage'];
  try { return await lp.pw.chromium.launch({ args }); }
  catch (e) {
    const exe = findChromium();
    if (!exe) throw new EnvError('크로미움을 찾지 못했어요 — ' + String(e.message).split('\n')[0]);
    return await lp.pw.chromium.launch({ args, executablePath: exe });
  }
}
class EnvError extends Error {}

// ───────── 글 → HTML ─────────
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const br = s => esc(s).replace(/\n/g, '<br>');
function withEm(text, em) {
  let h = esc(text);
  if (em) { const e = esc(em); const i = h.indexOf(e); if (i >= 0) h = h.slice(0, i) + '<em>' + e + '</em>' + h.slice(i + e.length); }
  return h.replace(/\n/g, '<br>');
}
const promptHtml = s => esc(s.replace(/\s+$/, '')).replace(/\[[^\]\n]+\]/g, m => '<mark>' + m + '</mark>');
const oneLine = v => String(v || '').replace(/\s*\n\s*/g, ' ').trim();
const dot = d => String(d).slice(0, 10).replace(/-/g, '.');
const sha256 = b => crypto.createHash('sha256').update(b).digest('hex');
function localTime() {
  const d = new Date(), z = -d.getTimezoneOffset(), p = v => String(Math.floor(Math.abs(v))).padStart(2, '0');
  return new Date(d.getTime() + z * 60000).toISOString().slice(0, 19) + (z >= 0 ? '+' : '-') + p(z / 60) + ':' + p(z % 60);
}
// AI 답(마크다운)을 그대로 보여 주기 위한 작은 변환기 — 글은 바꾸지 않고 모양만 입힌다
function md(src) {
  const L = String(src).replace(/\r/g, '').split('\n'), out = [];
  const inl = s => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/__([^_]+)__/g, '<strong>$1</strong>');
  const isSep = r => { const c = r.trim().replace(/^\||\|$/g, '').split('|'); return c.length > 0 && c.every(x => /^\s*:?-{2,}:?\s*$/.test(x)); };
  const cells = r => r.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
  const UL = /^\s*[-*+•·]\s+/, OL = /^\s*\d+[.)]\s+/, BLOCK = /^(\s*$|```|#{1,6}\s|\s*\||>\s?|\s*(-{3,}|\*{3,}|_{3,})\s*$)/;
  let i = 0;
  while (i < L.length) {
    const l = L[i]; let m;
    if (/^\s*$/.test(l)) { i++; continue; }
    if (/^```/.test(l)) { const b = []; i++; while (i < L.length && !/^```/.test(L[i])) b.push(L[i++]); i++; out.push(`<pre>${esc(b.join('\n'))}</pre>`); continue; }
    if ((m = l.match(/^(#{1,6})\s+(.*)$/))) { const n = Math.min(m[1].length + 1, 4); out.push(`<h${n}>${inl(m[2])}</h${n}>`); i++; continue; }
    if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(l)) { out.push('<hr>'); i++; continue; }
    if (/^\s*\|/.test(l)) {
      const rows = []; while (i < L.length && /^\s*\|/.test(L[i])) rows.push(L[i++]);
      const head = rows.length > 1 && isSep(rows[1]) ? cells(rows[0]) : null, body = rows.filter((r, k) => !(head && k <= 1) && !isSep(r));
      out.push('<table>' + (head ? '<thead><tr>' + head.map(c => `<th>${inl(c)}</th>`).join('') + '</tr></thead>' : '') + '<tbody>' + body.map(r => '<tr>' + cells(r).map(c => `<td>${inl(c)}</td>`).join('') + '</tr>').join('') + '</tbody></table>');
      continue;
    }
    if (/^>\s?/.test(l)) { const b = []; while (i < L.length && /^>\s?/.test(L[i])) b.push(L[i++].replace(/^>\s?/, '')); out.push(`<blockquote>${b.map(inl).join('<br>')}</blockquote>`); continue; }
    if (UL.test(l) || OL.test(l)) {
      const ord = OL.test(l) && !UL.test(l), re = ord ? OL : UL, items = [];
      while (i < L.length && re.test(L[i])) { let t = L[i++].replace(re, ''); while (i < L.length && /^\s{2,}\S/.test(L[i]) && !UL.test(L[i]) && !OL.test(L[i])) t += ' ' + L[i++].trim(); items.push(t); }
      out.push(`<${ord ? 'ol' : 'ul'}>` + items.map(t => `<li>${inl(t)}</li>`).join('') + `</${ord ? 'ol' : 'ul'}>`);
      continue;
    }
    const b = []; while (i < L.length && !BLOCK.test(L[i]) && !UL.test(L[i]) && !OL.test(L[i])) b.push(L[i++]);
    out.push(`<p>${b.map(inl).join('<br>')}</p>`);
  }
  return out.join('\n');
}

// ───────── 작업 재료 읽기: 화면 모음 · 실행 결과 ─────────
function loadLibrary(lib) {
  try { const j = JSON.parse(fs.readFileSync(path.join(lib, 'index.json'), 'utf8')); return (j && j.shots) || {}; } catch (e) { return {}; }
}
function loadRuns(job) {
  const dir = path.join(job, 'runs');
  let j = null;
  try { j = JSON.parse(fs.readFileSync(path.join(dir, 'runs.json'), 'utf8')); } catch (e) { return null; }
  const runs = {};
  for (const [k, v] of Object.entries(j.runs || {})) {
    const f = path.join(dir, `${k}.md`);
    if (fs.existsSync(f)) runs[k] = Object.assign({}, v, { text: fs.readFileSync(f, 'utf8'), file: f });
  }
  return { meta: j, runs };
}
// 샷 참조: "shots/02.png"(작업 폴더) 또는 "lib:chatgpt-phone/02-new-chat.jpg"(화면 모음)
function shotRef(ref, ctx) {
  if (typeof ref !== 'string' || !ref.trim()) return null;
  if (ref.startsWith('lib:')) {
    const name = ref.slice(4), abs = path.resolve(ctx.lib, name);
    if (!abs.startsWith(path.resolve(ctx.lib) + path.sep) || !fs.existsSync(abs)) return null;
    return { abs, lib: ctx.libIndex[name] || null, name };
  }
  const abs = path.resolve(ctx.job, ref);
  if (!abs.startsWith(path.resolve(ctx.job) + path.sep) || !/\.(png|jpe?g|webp)$/i.test(abs) || !fs.existsSync(abs)) return null;
  return { abs, lib: null, name: ref };
}
// 직접 해 본 기록: deck.tested 가 있으면 그대로, 없으면 실행 결과에서 만든다
function deriveTested(deck, R) {
  if (deck.tested) return deck.tested;
  const used = [...new Set((deck.slides || []).filter(s => s && s.type === 'answer').flatMap(s => [s.run].concat(Array.isArray(s.also) ? s.also : [])))].filter(k => R && R.runs[k]);
  if (!used.length) return null;
  const dates = used.map(k => String(R.runs[k].at || '').slice(0, 10)).sort();
  return { date: dates[0], device: 'API 실행', app: used.map(k => R.runs[k].label || k).join(', '), plan: 'API' };
}

// ───────── 검사 1: deck.json ─────────
function validate(deck, ctx) {
  const E = [], W = [];
  const isStr = v => typeof v === 'string' && v.trim().length > 0;
  const rect = v => Array.isArray(v) && v.length === 4 && v.every(x => typeof x === 'number' && x >= 0 && x <= 100) && v[0] < v[2] && v[1] < v[3];
  const shotOk = (ref, at, field) => {
    const r = shotRef(ref, ctx);
    if (!r) { E.push(`${at}: ${field} — 작업 폴더 안 캡처(shots/…) 또는 화면 모음(lib:…) 경로`); return; }
    if (ref.startsWith('lib:')) {
      const m = r.lib;
      if (!m) E.push(`${at}: ${field} — 화면 모음 index.json 에 등록되지 않은 화면이에요(${r.name}) → render.js --import 로 등록`);
      else if (!/^\d{4}-\d{2}-\d{2}$/.test(m.date || '') || !isStr(m.app)) E.push(`${at}: ${field} — 화면 모음 ${r.name} 의 date·app 이 비었어요`);
    }
  };
  const R = ctx.runs;
  if (!/^\d{3}$/.test(deck.no || '')) E.push('no: 자료실 번호 세 자리 문자열(예: "001")');
  if (!isStr(deck.topic) || deck.topic.length > 12) E.push('topic: 주제 이름 1~12자(예: "회의록")');
  if (deck.tested != null) {
    const t = deck.tested || {};
    if (!/^\d{4}[.-]\d{2}[.-]\d{2}$/.test(t.date || '')) E.push('tested.date: 직접 해 본 날짜, "2026-10-29" 형식');
    if (!isStr(t.device)) E.push('tested.device: 기준 기기(예: "휴대폰 앱", "API 실행")');
  }
  const S = Array.isArray(deck.slides) ? deck.slides : [];
  if (!S.length) E.push('slides: 장 목록이 비었어요');
  else {
    if (S[0].type !== 'cover') E.push('1장은 cover(표지)여야 해요');
    if (S[S.length - 1].type !== 'end') E.push('마지막 장은 end(마무리)여야 해요');
    if (S.length !== 6) W.push(`장 수 ${S.length}장 — 이 계정 기준은 6장(check_card.py)`);
  }
  const runOk = (k, at, field) => { if (!isStr(k) || !R || !R.runs[k]) E.push(`${at}: ${field} — runs/${k}.md 가 없어요(ask.py 로 먼저 실행)`); };
  S.forEach((s, i) => {
    const at = `${i + 1}장(${s && s.type})`;
    if (!s || typeof s !== 'object') { E.push(`${at}: 형식 오류`); return; }
    if (s.step != null && !(Number.isInteger(s.step) && s.step > 0 && s.step < 10)) E.push(`${at}: step — 단계 번호 1~9`);
    switch (s.type) {
      case 'cover':
        if (typeof s.bg === 'string' && s.bg.startsWith('@')) runOk(s.bg.slice(1), at, 'bg');
        else shotOk(s.bg, at, 'bg');
        if (!Array.isArray(s.lines) || s.lines.length < 1 || s.lines.length > 2 || !s.lines.every(isStr)) E.push(`${at}: lines — 크림 자막 1~2줄(상황)`);
        if (!isStr(s.hit)) E.push(`${at}: hit — 주황 자막 1줄(해결)`);
        if (s.pos != null && !['mid', 'lower'].includes(s.pos)) E.push(`${at}: pos — "mid" 또는 "lower"`);
        if (s.tone != null && !['dark', 'light'].includes(s.tone)) E.push(`${at}: tone — "dark" 또는 "light"`);
        if (s.bg_pos != null && !/^\d{1,3}% \d{1,3}%$/.test(s.bg_pos)) E.push(`${at}: bg_pos — "50% 30%" 형식`);
        break;
      case 'step': case 'result':
        if (s.type === 'step' && s.step == null) E.push(`${at}: step — 단계 번호`);
        if (!isStr(s.title)) E.push(`${at}: title — 제목`);
        shotOk(s.shot, at, 'shot');
        if (s.mark != null && !rect(s.mark)) E.push(`${at}: mark — [x0, y0, x1, y1] 0~100(%)`);
        if (s.focus != null && !(typeof s.focus === 'number' && s.focus >= 0 && s.focus <= 100)) E.push(`${at}: focus — 0~100(%)`);
        if (s.path != null && (!Array.isArray(s.path) || s.path.length < 1 || s.path.length > 4 || !s.path.every(isStr))) E.push(`${at}: path — 글 1~4개 목록`);
        if (s.type === 'step' && !s.mark) W.push(`${at}: mark 없음 — 어디를 누르는지 강조하면 따라 하기 쉬워요`);
        break;
      case 'answer':
        if (!isStr(s.title)) E.push(`${at}: title — 제목`);
        runOk(s.run, at, 'run');
        if (s.mark != null && !isStr(s.mark)) E.push(`${at}: mark — 답에 실제로 있는 글 일부(예: "견적서 작성")`);
        if (s.also != null) { if (!Array.isArray(s.also)) E.push(`${at}: also — 실행 이름 목록(예: ["claude"])`); else s.also.forEach(k => runOk(k, at, 'also')); }
        break;
      case 'prompt':
        if (!isStr(s.title)) E.push(`${at}: title — 제목`);
        if (!isStr(s.prompt)) E.push(`${at}: prompt — 프롬프트 본문`);
        else if (!/\[[^\]\n]+\]/.test(s.prompt)) W.push(`${at}: prompt 에 [바꿀 곳] 표시가 없어요`);
        break;
      case 'end':
        if (!Array.isArray(s.lines) || s.lines.length < 1 || s.lines.length > 3 || !s.lines.every(isStr)) E.push(`${at}: lines — 큰 글 1~3줄`);
        if (!isStr(s.dm)) E.push(`${at}: dm — DM으로 받는 것(예: "전체 프롬프트 3개를 DM으로 보내 드려요")`);
        break;
      default: E.push(`${at}: type 은 cover·step·prompt·answer·result·end 중 하나`);
    }
    const vals = ['title', 'desc', 'hit', 'prompt', 'hint', 'more', 'dm', 'cue', 'em', 'label'].map(k => s[k]).concat(Array.isArray(s.lines) ? s.lines : [], Array.isArray(s.path) ? s.path : []);
    for (const v of vals) if (typeof v === 'string' && /\p{Extended_Pictographic}/u.test(v)) E.push(`${i + 1}장: 이모지는 쓰지 않아요(글꼴에 없어 서버마다 다르게 보임) — "${v.slice(0, 16)}"`);
  });
  // 실제로 돌린 프롬프트와 장에 보이는 프롬프트가 같은가 (보여 준 답이 이 프롬프트에서 나왔다는 보증)
  const usesRuns = S.some(s => s && (s.type === 'answer' || (s.type === 'cover' && typeof s.bg === 'string' && s.bg.startsWith('@'))));
  if (usesRuns) {
    let ptxt = null;
    try { ptxt = fs.readFileSync(path.join(ctx.job, 'prompt.txt'), 'utf8'); } catch (e) { E.push('prompt.txt 가 없어요 — 실제로 돌린 프롬프트 원문을 작업 폴더에 두세요'); }
    if (ptxt != null && R) {
      if (R.meta.prompt_sha256 !== sha256(Buffer.from(ptxt, 'utf8'))) E.push('prompt.txt 가 실행 뒤에 바뀌었어요 — ask.py 를 다시 돌리세요');
      const norm = v => v.replace(/\s+/g, ' ').trim(), whole = norm(ptxt);
      S.filter(s => s && s.type === 'prompt' && typeof s.prompt === 'string').forEach(s => {
        const miss = s.prompt.split('\n').filter(l => l.trim() && !/\[[^\]\n]+\]/.test(l)).filter(l => !whole.includes(norm(l)));
        if (miss.length) E.push(`프롬프트 장의 글이 실제로 돌린 prompt.txt 에 없어요 — "${miss[0].slice(0, 20)}"`);
      });
      if (R.meta.example === true && !ctx.selftest) W.push('runs/ 가 예시 실행 결과예요 — 게시물에는 ask.py 로 실제 실행한 결과를 쓰세요');
    }
  }
  if (!deck.tested && !deriveTested(deck, R)) E.push('tested: 직접 해 본 날짜·기기를 쓰거나(answer 장이 없을 때) ask.py 실행 결과를 두세요');
  if (deck.masks != null) {
    if (typeof deck.masks !== 'object' || Array.isArray(deck.masks)) E.push('masks: {"shots/01.png": [[x0, y0, x1, y1], …]} 형식');
    else for (const [k, v] of Object.entries(deck.masks)) {
      if (!shotRef(k, ctx)) E.push(`masks: ${k} — 작업 폴더 캡처나 화면 모음이 아니에요`);
      if (!Array.isArray(v) || !v.length || !v.every(rect)) E.push(`masks: ${k} — [[x0, y0, x1, y1], …] 0~100(%)`);
    }
  }
  return { E, W };
}

// ───────── 장 만들기 ─────────
function buildHtml(deck, ctx, imgUrl) {
  const d = deck, t = deriveTested(deck, ctx.runs), td = dot(t.date), R = ctx.runs;
  const chip = `<div class="chip"><span class="b"><span class="cm">ai<i></i></span>AI 자료실</span><span>No.${esc(d.no)}</span></div>`;
  const pill = (s, dflt) => `<span class="pill">${esc(s.label || (s.step ? 'STEP ' + s.step : dflt))}</span>`;
  const top = (s, dflt) => `<div class="top">${pill(s, dflt)}<span class="meta">No.${esc(d.no)} · ${esc(d.topic)}</span></div>`;
  const foot = text => `<p class="foot"><span class="one">${esc(text)}</span></p>`;
  const shotFoot = (ref, word) => { const r = shotRef(ref, ctx); return r && r.lib ? `${word} · ${dot(r.lib.date)} · ${r.lib.app}${r.lib.device ? ` (${r.lib.device})` : ''}` : `${word} · ${td} · ${t.device} 기준`; };
  const frame = (s, min) => `<div class="frame" data-min="${min}"${s.mark ? ` data-mark="${esc(JSON.stringify(s.mark))}"` : ''}${s.focus != null ? ` data-focus="${+s.focus}"` : ''}${s.step ? ` data-n="${+s.step}"` : ''}><img src="${imgUrl(s.shot)}" alt=""><span class="hl"><b></b></span></div>`;
  const label = k => (R.runs[k].label || k);
  const out = d.slides.map(s => {
    switch (s.type) {
      case 'cover': {
        const bg = typeof s.bg === 'string' && s.bg.startsWith('@')
          ? `<div class="bg deco ansbg"><div class="ans-body">${md(R.runs[s.bg.slice(1)].text)}</div></div>`
          : `<div class="bg deco"><img src="${imgUrl(s.bg)}" style="object-position:${esc(s.bg_pos || '50% 30%')}" alt=""></div>`;
        return `<section class="slide cover${s.tone === 'light' ? ' light' : ''}">
  ${bg}
  <div class="dim deco"></div>
  ${chip}
  <div class="caps ${s.pos === 'lower' ? 'lower' : 'mid'}">${s.lines.map(l => `<span class="one">${esc(l)}</span>`).join('')}<span class="one k">${esc(s.hit)}</span></div>
  <p class="cue one">${esc(s.cue || '실제 화면으로 따라 하기')}</p>
</section>`;
      }
      case 'step': return `<section class="slide body step">
  ${top(s, 'STEP')}
  <h2 class="ttl" data-max-lines="2">${withEm(s.title, s.em)}</h2>
  ${s.desc ? `<p class="desc" data-max-lines="2">${br(s.desc)}</p>` : ''}
  ${frame(s, 400)}
  ${s.path ? `<div class="path">${s.path.map(p => `<span class="one">${esc(p)}</span>`).join('<i>→</i>')}</div>` : ''}
  ${foot(shotFoot(s.shot, '실제 화면'))}
</section>`;
      case 'result': return `<section class="slide body result">
  ${top(s, '결과')}
  <h2 class="ttl" data-max-lines="2">${withEm(s.title, s.em)}</h2>
  ${s.desc ? `<p class="desc" data-max-lines="2">${br(s.desc)}</p>` : ''}
  ${frame(s, 460)}
  ${foot(shotFoot(s.shot, '실제 결과'))}
</section>`;
      case 'answer': {
        const run = R.runs[s.run], also = (s.also || []).map(k => (R.runs[k].short || label(k)));
        return `<section class="slide body answer">
  ${top(s, '결과')}
  <h2 class="ttl" data-max-lines="2">${withEm(s.title, s.em)}</h2>
  ${s.desc ? `<p class="desc" data-max-lines="2">${br(s.desc)}</p>` : ''}
  <div class="frame ansf" data-min="460"${s.mark ? ` data-find="${esc(s.mark)}"` : ''}${s.step ? ` data-n="${+s.step}"` : ''}>
    <div class="ans-bar"><span><b>${esc(label(s.run))}</b> 실제 답</span><span>${esc(dot(run.at))} 실행</span></div>
    <div class="ans-view"><div class="ans-body">${md(run.text)}</div><span class="hl"><b></b></span></div>
  </div>
  ${foot(`실제 결과 · ${dot(run.at)} · ${label(s.run)}${also.length ? ` · ${also.join('·')}에서도 확인` : ''}`)}
</section>`;
      }
      case 'prompt': return `<section class="slide body prompt">
  ${top(s, '프롬프트')}
  <h2 class="ttl" data-max-lines="2">${withEm(s.title, s.em)}</h2>
  <div class="code"><div class="ch"><b>프롬프트</b><span>길게 눌러 복사</span></div><p>${promptHtml(s.prompt)}</p></div>
  ${s.hint || s.more ? `<div class="hint">${s.hint ? `<b class="one">${esc(s.hint)}</b>` : ''}${s.more ? `<span class="one">${esc(s.more)}</span>` : ''}</div>` : ''}
  ${foot(`직접 해 본 기준 · ${td} · ${t.app || t.device}`)}
</section>`;
      case 'end': return `<section class="slide end">
  <div class="top"><div class="brand"><span class="bm">ai<i></i></span>AI 자료실</div><span class="no">No.${esc(d.no)}</span></div>
  <h2 class="ttl" data-max-lines="${s.lines.length}">${s.lines.map(esc).join('<br>')}</h2>
  <div class="bubble"><p class="l1 one"><em>아무 댓글</em>이나 남기면</p><p class="l2 one">${esc(s.dm)}</p></div>
  <div class="eb"><div class="r1"><span class="one">DM이 안 오면 자료실에서 No.${esc(d.no)}</span><span class="url">${URL_TEXT}</span></div><p class="r2">${esc(PROMISE)}</p></div>
</section>`;
    }
  }).join('\n');
  return `<!doctype html><html lang="ko"><head><meta charset="utf-8"><base href="${pathToFileURL(HERE + path.sep).href}"><link rel="stylesheet" href="cards.css"></head><body>\n${out}\n</body></html>`;
}

// 메타(check_card.py 가 읽는 장별 제목·본문) — 렌더된 글과 같게 렌더기가 쓴다
function metaSlides(deck) {
  return deck.slides.map(s => Object.assign({ kind: s.type }, metaOne(s)));
}
function metaOne(s) {
  switch (s.type) {
    case 'cover': return { type: 'cover', title: s.lines.join(' '), body: s.hit };
    case 'step': return { type: 'step', title: oneLine(s.title), body: oneLine(s.desc), note: (s.path || []).join(' → ') };
    case 'result': return { type: 'result', title: oneLine(s.title), body: oneLine(s.desc) };
    case 'answer': return { type: 'answer', title: oneLine(s.title), body: oneLine(s.desc), note: `run: ${s.run}${(s.also || []).length ? ' · also: ' + s.also.join(', ') : ''}` };
    case 'prompt': return { type: 'prompt', title: oneLine(s.title), body: s.prompt.trim(), note: [s.hint, s.more].filter(Boolean).join(' / ') };
    case 'end': return { type: 'end', title: s.lines.join(' '), body: `${CTA} ${s.dm}` };
  }
}

// ───────── 페이지 안에서 도는 코드 ─────────
function pageLayout() {
  const probs = [], slideNo = el => [...document.querySelectorAll('.slide')].indexOf(el.closest('.slide')) + 1;
  const badge = (hl, x0, y0, n) => { const b = hl.querySelector('b'); if (n) { b.textContent = n; b.style.left = (Math.max(x0 - 46, 10) - x0) + 'px'; b.style.top = (Math.max(y0 - 46, 10) - y0) + 'px'; } else b.remove(); };
  // 캡처 틀
  document.querySelectorAll('.frame:not(.ansf)').forEach(fr => {
    const img = fr.querySelector('img'), hl = fr.querySelector('.hl');
    const W = fr.clientWidth, H = fr.clientHeight, nw = img.naturalWidth, nh = img.naturalHeight;
    if (!nw || !W || !H) return;
    const ih = nh * W / nw;
    img.style.width = W + 'px'; img.style.height = ih + 'px';
    const mk = fr.dataset.mark ? JSON.parse(fr.dataset.mark) : null;
    let off = 0;
    if (ih <= H) off = (H - ih) / 2;
    else if (fr.dataset.focus || mk) {
      const cy = fr.dataset.focus ? +fr.dataset.focus / 100 * ih : (mk[1] + mk[3]) / 200 * ih;
      off = -Math.min(Math.max(cy - H / 2, 0), ih - H);
    }
    img.style.top = off + 'px';
    if (!mk) return;
    const pad = 14;
    let x0 = mk[0] / 100 * W, x1 = mk[2] / 100 * W, y0 = mk[1] / 100 * ih + off, y1 = mk[3] / 100 * ih + off;
    if (y1 < pad + 20 || y0 > H - pad - 20) { probs.push(`${slideNo(fr)}장: 강조 위치(mark)가 화면 틀 밖이에요 — focus 를 지우거나 mark 를 확인하세요`); return; }
    x0 = Math.max(x0, pad); y0 = Math.max(y0, pad); x1 = Math.min(x1, W - pad); y1 = Math.min(y1, H - pad);
    Object.assign(hl.style, { display: 'block', left: x0 + 'px', top: y0 + 'px', width: (x1 - x0) + 'px', height: (y1 - y0) + 'px' });
    badge(hl, x0, y0, fr.dataset.n);
  });
  // 실제 답 틀: mark 글이 들어 있는 덩어리(표·목록·문단)를 찾아 가운데에 보이게 하고 테두리를 친다
  document.querySelectorAll('.frame.ansf').forEach(fr => {
    const view = fr.querySelector('.ans-view'), body = fr.querySelector('.ans-body'), hl = fr.querySelector('.hl');
    const H = view.clientHeight, BH = body.scrollHeight, want = fr.dataset.find;
    let target = null;
    if (want) {
      const norm = v => v.replace(/\s+/g, ' ').trim(), w = norm(want);
      const blocks = [...body.querySelectorAll('table,ul,ol,pre,blockquote,p,h2,h3,h4')];
      target = blocks.find(b => b.matches('table') && norm(b.textContent).includes(w)) || blocks.find(b => !b.closest('table,ul,ol') && norm(b.textContent).includes(w)) || blocks.find(b => norm(b.textContent).includes(w));
      if (!target) probs.push(`${slideNo(fr)}장: mark 글 "${want.slice(0, 16)}" 을 실제 답에서 찾지 못했어요 — 답에 있는 글을 그대로 쓰세요`);
    }
    let off = 0;
    if (target) {
      const ty = target.offsetTop, th = target.offsetHeight;
      off = th + 60 > H ? Math.max(ty - 30, 0) : Math.min(Math.max(ty + th / 2 - H / 2, 0), Math.max(BH - H, 0));
    }
    body.style.top = -off + 'px';
    if (off > 4) view.classList.add('cut-top');
    if (BH - off > H + 4) view.classList.add('cut-bottom');
    if (!target) { hl.remove(); return; }
    const pad = 12, W = view.clientWidth;
    let x0 = target.offsetLeft - 6, x1 = target.offsetLeft + target.offsetWidth + 6, y0 = target.offsetTop - off - 6, y1 = target.offsetTop - off + target.offsetHeight + 6;
    x0 = Math.max(x0, pad); y0 = Math.max(y0, pad); x1 = Math.min(x1, W - pad); y1 = Math.min(y1, H - pad);
    Object.assign(hl.style, { display: 'block', left: x0 + 'px', top: y0 + 'px', width: (x1 - x0) + 'px', height: (y1 - y0) + 'px' });
    // 답 틀에서는 번호를 오른쪽 위에 둔다(왼쪽 위는 보통 제목 글자가 있어서)
    const b = hl.querySelector('b');
    if (fr.dataset.n) { b.textContent = fr.dataset.n; b.style.left = (Math.min(x1 - 16, W - 70) - x0) + 'px'; b.style.top = (Math.max(y0 - 46, 10) - y0) + 'px'; } else b.remove();
  });
  return probs;
}
// 프롬프트 장: 글이 길면 프롬프트 글씨를 35px → 28px 까지 한 단계씩 줄여 맞춘다(check_card 의 프롬프트 180자 기준에 맞춤)
function pageFitPrompts(arg) {
  const { SLIDE_H, BODY_BOTTOM } = arg, steps = [[35, 1.75], [33, 1.72], [31, 1.68], [29, 1.64], [28, 1.6]], used = [];
  document.querySelectorAll('.slide.prompt').forEach(s => {
    const p = s.querySelector('.code p'), lim = s.getBoundingClientRect().top + SLIDE_H - BODY_BOTTOM;
    const over = () => [...s.children].some(c => !c.classList.contains('foot') && c.getBoundingClientRect().bottom > lim + 2);
    for (const [fs, lh] of steps) { p.style.fontSize = fs + 'px'; p.style.lineHeight = String(lh); if (!over()) break; }
    used.push(parseFloat(p.style.fontSize));
  });
  return used;
}
function pageChecks(arg) {
  const { SAFE, SLIDE_H, BODY_BOTTOM, fonts } = arg;
  const errs = [];
  const lines = e => { const rg = document.createRange(); rg.selectNodeContents(e); const tops = [...rg.getClientRects()].filter(q => q.width > 1).map(q => q.top).sort((a, b) => a - b); let n = 0, last = -1e9; for (const t of tops) { if (t - last > 10) { n++; last = t; } } return n; };
  const deco = e => e && e.closest('.deco,.frame');
  document.querySelectorAll('.slide').forEach((s, i) => {
    const n = i + 1, r = s.getBoundingClientRect(), cut = v => v.replace(/\s+/g, ' ').trim().slice(0, 18);
    s.querySelectorAll('.one').forEach(e => { if (lines(e) > 1) errs.push(`${n}장: 한 줄에 안 들어가요 — "${cut(e.textContent)}"`); });
    s.querySelectorAll('[data-max-lines]').forEach(e => { const L = lines(e); if (L > +e.dataset.maxLines) errs.push(`${n}장: ${L}줄이에요(최대 ${e.dataset.maxLines}줄) — "${cut(e.textContent)}"`); });
    [...s.querySelectorAll('*')].filter(e => !deco(e)).forEach(e => { const q = e.getBoundingClientRect(); if (q.width && (q.right > r.right + 1 || q.bottom > r.bottom + 1 || q.left < r.left - 1 || q.top < r.top - 1)) errs.push(`${n}장: 장 밖으로 나가요 — ${e.className || e.tagName}`); });
    const tw = document.createTreeWalker(s, NodeFilter.SHOW_TEXT); let t;
    while ((t = tw.nextNode())) {
      if (!t.textContent.trim() || deco(t.parentElement)) continue;
      const rg = document.createRange(); rg.selectNodeContents(t);
      for (const q of rg.getClientRects()) if (q.width && (q.left < r.left + SAFE - 1 || q.right > r.right - SAFE + 1)) { errs.push(`${n}장: 글자가 좌우 여백(${SAFE}px) 밖이에요 — "${cut(t.textContent)}"`); break; }
    }
    s.querySelectorAll('.frame').forEach(f => { if (f.clientHeight < +f.dataset.min) errs.push(`${n}장: 글이 길어 화면 틀이 ${f.clientHeight}px로 작아졌어요(최소 ${f.dataset.min}px) — 제목·설명을 줄이세요`); });
    if (s.classList.contains('body')) {
      const lim = r.top + SLIDE_H - BODY_BOTTOM + 2;
      if ([...s.children].some(c => !c.classList.contains('foot') && c.getBoundingClientRect().bottom > lim)) errs.push(`${n}장: 내용이 길어 아래 출처 줄과 겹쳐요 — ${s.classList.contains('prompt') ? '프롬프트나 아래 안내' : '제목·설명·경로'}를 줄이세요`);
    }
    if (s.classList.contains('cover')) {
      const caps = s.querySelector('.caps').getBoundingClientRect(), cue = s.querySelector('.cue').getBoundingClientRect(), chip = s.querySelector('.chip').getBoundingClientRect();
      if (caps.bottom > cue.top - 30) errs.push(`${n}장: 자막이 아래 문구와 겹쳐요 — 줄 수를 줄이거나 pos 를 바꾸세요`);
      if (caps.top < chip.bottom + 40) errs.push(`${n}장: 자막이 위 번호와 겹쳐요 — 줄 수를 줄이거나 pos 를 바꾸세요`);
    }
    if (s.classList.contains('end')) {
      const bb = s.querySelector('.bubble').getBoundingClientRect(), eb = s.querySelector('.eb').getBoundingClientRect();
      if (bb.bottom + 34 > eb.top - 24) errs.push(`${n}장: 말풍선이 아래 안내와 겹쳐요 — 큰 글을 줄이세요`);
    }
  });
  document.querySelectorAll('img').forEach(im => { if (!im.complete || !im.naturalWidth) errs.push(`캡처를 못 읽었어요 — ${decodeURIComponent(im.src.split('/').pop())}`); });
  const loaded = new Set([...document.fonts].filter(f => f.status === 'loaded').map(f => f.family.replace(/["']/g, '') + ':' + f.weight));
  for (const k of fonts) if (!loaded.has(k)) errs.push(`글꼴이 불러와지지 않았어요 — ${k} (templates/fonts 확인)`);
  return errs;
}

// ───────── 렌더 ─────────
// 가리기: deck.masks(작업 캡처·화면 모음 모두) + 화면 모음 index.json 의 masks 를 합쳐, 가린 사본을 만들어 쓴다
async function prepareImages(browser, deck, ctx, tmp) {
  const want = {};
  const add = (ref, rects) => { const r = shotRef(ref, ctx); if (r && rects && rects.length) (want[r.abs] = want[r.abs] || []).push(...rects); };
  for (const [k, v] of Object.entries(deck.masks || {})) add(k, v);
  const refs = new Set(deck.slides.flatMap(s => [s.shot, s.bg]).filter(v => typeof v === 'string' && v.startsWith('lib:')));
  for (const ref of refs) { const r = shotRef(ref, ctx); if (r && r.lib && Array.isArray(r.lib.masks)) add(ref, r.lib.masks); }
  const map = {};
  let i = 0;
  for (const [abs, rects] of Object.entries(want)) {
    const out = path.join(tmp, `masked-${++i}.png`), page = path.join(tmp, `mask-${i}.html`);
    fs.writeFileSync(page, `<!doctype html><html><body style="margin:0"><div id="w" style="position:relative;display:inline-block"><img src="${pathToFileURL(abs).href}" style="display:block">${rects.map(r => `<div style="position:absolute;left:${r[0]}%;top:${r[1]}%;width:${r[2] - r[0]}%;height:${r[3] - r[1]}%;background:#d6d3ce;border-radius:10px"></div>`).join('')}</div></body></html>`);
    const p = await browser.newPage({ viewport: { width: 1200, height: 1200 }, deviceScaleFactor: 1 });
    await p.goto(pathToFileURL(page).href, { waitUntil: 'load' });
    await (await p.$('#w')).screenshot({ path: out });
    await p.close();
    map[abs] = out;
  }
  return ref => { const r = shotRef(ref, ctx); return pathToFileURL(map[r.abs] || r.abs).href; };
}

async function render(job, opts = {}) {
  job = path.resolve(job);
  const rel = path.relative(HERE, job);
  if (!opts.allowInside && (rel === '' || !rel.startsWith('..'))) throw new EnvError('템플릿 폴더 안에서는 렌더하지 않아요 — 작업 폴더(outbox/pending/<ID>)를 주세요');
  let deck;
  try { deck = JSON.parse(fs.readFileSync(path.join(job, 'deck.json'), 'utf8')); }
  catch (e) { throw new EnvError(`deck.json 을 읽지 못했어요 — ${e.code === 'ENOENT' ? '파일 없음' : e.message.split('\n')[0]}`); }
  const lib = path.resolve(opts.lib || LIB_DEFAULT);
  const ctx = { job, lib, libIndex: loadLibrary(lib), runs: loadRuns(job), selftest: !!opts.selftest };
  const result = { ok: false, renderer: VERSION, rendered_at: localTime(), slides: 0, errors: [], warnings: [] };
  const { E, W } = validate(deck, ctx);
  result.warnings.push(...W);
  if (E.length) { result.errors = E; fs.writeFileSync(path.join(job, 'render.json'), JSON.stringify(result, null, 1)); return result; }

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'render-'));
  const browser = await launch();
  try {
    result.chromium = browser.version();
    const imgUrl = await prepareImages(browser, deck, ctx, tmp);
    const htmlPath = path.join(tmp, 'deck.html');
    fs.writeFileSync(htmlPath, buildHtml(deck, ctx, imgUrl));
    const page = await browser.newPage({ viewport: { width: SLIDE_W, height: SLIDE_H }, deviceScaleFactor: 1 });
    await page.goto(pathToFileURL(htmlPath).href, { waitUntil: 'load' });
    await page.evaluate(() => document.fonts.ready);
    await page.evaluate(() => Promise.all([...document.images].map(i => i.complete ? 0 : new Promise(r => { i.onload = i.onerror = r; }))));
    const fonts = ['SUIT:400', 'SUIT:700', 'SUIT:800', 'SUIT:900'].concat(deck.slides.some(s => s.type === 'prompt') ? ['Code:400'] : []);
    const promptSizes = await page.evaluate(pageFitPrompts, { SLIDE_H, BODY_BOTTOM });
    if (promptSizes.some(v => v < 35)) result.warnings.push(`프롬프트가 길어 글씨를 ${Math.min(...promptSizes)}px로 줄였어요`);
    const layoutProblems = await page.evaluate(pageLayout);
    const errs = layoutProblems.concat(await page.evaluate(pageChecks, { SAFE, SLIDE_H, BODY_BOTTOM, fonts }));
    result.errors = [...new Set(errs)];
    const slides = await page.$$('.slide');
    const outDir = result.errors.length ? path.join(os.tmpdir(), `render-preview-${deck.no}`) : path.join(job, 'slides');
    fs.mkdirSync(outDir, { recursive: true });
    for (const f of fs.readdirSync(outDir)) if (/^\d{2}\.jpg$/.test(f)) fs.unlinkSync(path.join(outDir, f));
    for (let i = 0; i < slides.length; i++) await slides[i].screenshot({ path: path.join(outDir, String(i + 1).padStart(2, '0') + '.jpg'), type: 'jpeg', quality: 90 });
    result.slides = slides.length;
    if (result.errors.length) result.preview = outDir;
    else {
      const metaPath = path.join(job, 'meta.json');
      let meta = {};
      try { meta = JSON.parse(fs.readFileSync(metaPath, 'utf8')); } catch (e) { /* 새로 만든다 */ }
      meta.slides = metaSlides(deck);
      if (!meta.code) meta.code = deck.no;
      // 직접 해 본 기록: 그림 아래 줄과 같은 값을 meta 에도 (날짜는 check_card.py 형식 YYYY-MM-DD)
      const tt = deriveTested(deck, ctx.runs), keep = {};
      for (const k of ['app', 'plan', 'scope']) if (typeof tt[k] === 'string' && tt[k].trim()) keep[k] = tt[k];
      meta.tested = Object.assign({}, meta.tested || {}, { date: String(tt.date).replace(/\./g, '-'), device: tt.device }, keep);
      fs.writeFileSync(metaPath, JSON.stringify(meta, null, 1));
      result.ok = true;
    }
  } finally {
    await browser.close();
    fs.rmSync(tmp, { recursive: true, force: true });
  }
  fs.writeFileSync(path.join(job, 'render.json'), JSON.stringify(result, null, 1));
  return result;
}

// ───────── 화면 모음에 넣기 ─────────
async function importShot(src, name, o) {
  src = path.resolve(src);
  if (!fs.existsSync(src)) throw new EnvError(`원본 이미지가 없어요 — ${src}`);
  if (!/^[a-z0-9][a-z0-9._-]*(\/[a-z0-9][a-z0-9._-]*)*$/.test(name)) throw new EnvError('이름은 영어 소문자·숫자·-·_ 와 / 로 (예: chatgpt-phone/02-new-chat)');
  if (!o.app || !o.device || !/^\d{4}-\d{2}-\d{2}$/.test(o.date || '')) throw new EnvError('--app, --device, --date YYYY-MM-DD 가 필요해요');
  const lib = path.resolve(o.lib || LIB_DEFAULT), rel = name.replace(/\.(png|jpe?g|webp)$/i, '') + '.jpg', out = path.join(lib, rel);
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'import-')), page = path.join(tmp, 'i.html');
  fs.writeFileSync(page, `<!doctype html><html><body style="margin:0;background:#fff"><img id="i" src="${pathToFileURL(src).href}" style="display:block"></body></html>`);
  const browser = await launch();
  let size;
  try {
    const p = await browser.newPage({ viewport: { width: 1200, height: 1200 }, deviceScaleFactor: 1 });
    await p.goto(pathToFileURL(page).href, { waitUntil: 'load' });
    size = await p.evaluate(() => { const i = document.getElementById('i'); if (i.naturalWidth > 1290) { i.style.width = '1290px'; } return [i.naturalWidth, i.naturalHeight]; });
    if (!size[0]) throw new EnvError('이미지를 읽지 못했어요');
    await (await p.$('#i')).screenshot({ path: out, type: 'jpeg', quality: 88 });
  } finally { await browser.close(); fs.rmSync(tmp, { recursive: true, force: true }); }
  const ip = path.join(lib, 'index.json');
  let idx = { version: 1, shots: {} };
  try { idx = JSON.parse(fs.readFileSync(ip, 'utf8')); idx.shots = idx.shots || {}; } catch (e) { /* 새로 만든다 */ }
  const prev = idx.shots[rel] || {};
  idx.shots[rel] = Object.assign({ masks: [] }, prev, { app: o.app, device: o.device, date: o.date, note: o.note || prev.note || '' });
  fs.writeFileSync(ip, JSON.stringify(idx, null, 1));
  return { out, rel, size };
}

// ───────── 격자 그림 ─────────
async function grid(img, out) {
  img = path.resolve(img);
  if (!fs.existsSync(img)) throw new EnvError(`캡처 파일이 없어요 — ${img}`);
  out = path.resolve(out || path.join(os.tmpdir(), `grid-${path.basename(img).replace(/\.[^.]+$/, '')}.jpg`));
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'grid-'));
  const page = path.join(tmp, 'grid.html');
  fs.writeFileSync(page, `<!doctype html><html><head><base href="${pathToFileURL(HERE + path.sep).href}"><link rel="stylesheet" href="cards.css"></head><body style="margin:0;background:#fff">
<div id="w" style="position:relative;display:inline-block"><img id="i" src="${pathToFileURL(img).href}" style="display:block"></div>
<script>
const i = document.getElementById('i'), w = document.getElementById('w');
function draw() {
  i.style.width = (i.naturalWidth >= i.naturalHeight ? 1400 : 900) + 'px';
  for (let k = 5; k < 100; k += 5) {
    const major = k % 10 === 0, c = major ? 'rgba(230,0,90,.85)' : 'rgba(230,0,90,.32)', sz = major ? 2 : 1;
    const v = document.createElement('div'); v.style.cssText = 'position:absolute;top:0;bottom:0;left:' + k + '%;width:' + sz + 'px;background:' + c; w.appendChild(v);
    const h = document.createElement('div'); h.style.cssText = 'position:absolute;left:0;right:0;top:' + k + '%;height:' + sz + 'px;background:' + c; w.appendChild(h);
    if (major) for (const [css, txt] of [['left:' + k + '%;top:4px', 'x' + k], ['left:' + k + '%;bottom:4px', 'x' + k], ['top:' + k + '%;left:4px', 'y' + k], ['top:' + k + '%;right:4px', 'y' + k]]) {
      const l = document.createElement('span'); l.textContent = txt; l.style.cssText = 'position:absolute;' + css + ';transform:translate(' + (css.startsWith('left') ? '-50%' : '0') + ',' + (css.startsWith('top') ? '-50%' : '0') + ');padding:1px 6px;border-radius:6px;background:#fff;color:#c4004d;font:800 18px SUIT,sans-serif;border:1px solid #c4004d';
      w.appendChild(l);
    }
  }
  document.title = 'ready';
}
i.complete ? draw() : (i.onload = draw);
</script></body></html>`);
  const browser = await launch();
  try {
    const p = await browser.newPage({ viewport: { width: 1500, height: 1200 }, deviceScaleFactor: 1 });
    await p.goto(pathToFileURL(page).href, { waitUntil: 'load' });
    await p.waitForFunction(() => document.title === 'ready');
    await (await p.$('#w')).screenshot({ path: out, type: 'jpeg', quality: 85 });
  } finally { await browser.close(); fs.rmSync(tmp, { recursive: true, force: true }); }
  return out;
}

// ───────── 자체 시험 ─────────
async function selftest() {
  const ex = path.join(HERE, 'example');
  const job = fs.mkdtempSync(path.join(os.tmpdir(), 'render-selftest-'));
  copyDir(ex, job, name => name === 'slides');
  const r = await render(job, { lib: path.join(job, 'library'), selftest: true });
  const sizes = r.ok ? fs.readdirSync(path.join(job, 'slides')).map(f => jpegSize(path.join(job, 'slides', f))) : [];
  const sizeOk = sizes.length === 6 && sizes.every(s => s && s[0] === SLIDE_W && s[1] === SLIDE_H);
  return { r, job, sizeOk };
}
function copyDir(src, dst, skip) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    if (skip(e.name)) continue;
    const a = path.join(src, e.name), b = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(a, b, skip); else fs.copyFileSync(a, b);
  }
}
function jpegSize(p) {
  const b = fs.readFileSync(p); if (b[0] !== 0xff || b[1] !== 0xd8) return null;
  let i = 2;
  while (i + 9 < b.length) {
    if (b[i] !== 0xff) { i++; continue; }
    const m = b[i + 1];
    if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(m)) return [b.readUInt16BE(i + 7), b.readUInt16BE(i + 5)];
    if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) { i += 2; continue; }
    i += 2 + b.readUInt16BE(i + 2);
  }
  return null;
}

// ───────── 실행 ─────────
function envReport() {
  const lp = loadPlaywright();
  return [`node ${process.version}`, `playwright: ${lp ? lp.from : '없음'}`, `PLAYWRIGHT_BROWSERS_PATH=${process.env.PLAYWRIGHT_BROWSERS_PATH || '(없음)'}`, `크로미움 후보: ${findChromium() || '없음'}`].join(' · ');
}
function flags(a) { const o = {}; for (let i = 0; i < a.length; i++) if (a[i].startsWith('--')) o[a[i].slice(2)] = a[i + 1]; return o; }
async function main() {
  const a = process.argv.slice(2);
  if (!a.length || a[0] === '--help' || a[0] === '-h') { console.log(fs.readFileSync(__filename, 'utf8').split('\n').slice(1, 12).join('\n')); return 2; }
  if (a[0] === '--version') { console.log(VERSION); return 0; }
  if (a[0] === '--grid') { if (!a[1]) { console.log('사용: node render.js --grid <캡처> [출력.jpg]'); return 2; } console.log('격자 그림: ' + await grid(a[1], a[2])); return 0; }
  if (a[0] === '--import') {
    if (!a[1] || !a[2]) { console.log('사용: node render.js --import <원본> <이름> --app <앱> --device <기기> --date <YYYY-MM-DD> [--note <설명>]'); return 2; }
    const r = await importShot(a[1], a[2], flags(a.slice(3)));
    console.log(`화면 모음 등록 — lib:${r.rel} (${r.size[0]}×${r.size[1]}) → ${r.out}\n가릴 곳이 있으면 index.json 의 masks 에 [x0, y0, x1, y1](%)로 적으세요(--grid 로 위치 확인)`);
    return 0;
  }
  if (a[0] === '--selftest') {
    const { r, job, sizeOk } = await selftest();
    if (r.ok && sizeOk) { console.log(`자체 시험 통과 — ${r.slides}장 1080×1350 · ${r.chromium} · ${VERSION}\n결과: ${job}/slides`); return 0; }
    console.log(`자체 시험 실패 — ${r.errors.join(' / ') || '크기 확인 실패'}\n${envReport()}`); return 1;
  }
  const r = await render(a[0]);
  const w = r.warnings.length ? ` (경고 ${r.warnings.length}: ${r.warnings.join(' / ')})` : '';
  if (r.ok) { console.log(`렌더 통과 — ${r.slides}장 → ${path.join(path.resolve(a[0]), 'slides')}${w}`); return 0; }
  console.log(`렌더 실패 — 오류 ${r.errors.length}: ${r.errors.join(' / ')}${w}${r.preview ? `\n미리보기(검사 실패본): ${r.preview}` : ''}`);
  return 1;
}
main().then(c => process.exit(c), e => { console.log(`렌더기 오류 — ${e.message}${e instanceof EnvError ? '' : '\n' + e.stack}\n${envReport()}`); process.exit(2); });

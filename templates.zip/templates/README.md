# 디자인 v0 — 인스타 AI 계정(@aigents_ai) 카드뉴스

대표 확정 2026-10-30. 표지는 **화면 자막형**, 본문과 마무리는 **자료실형**(자료실 사이트와 같은 색·글꼴).
이 폴더는 원본이다. 직원은 고치지 않고, 고칠 점은 '개선 후보'로 비서실장에게 올린다.

## 한눈에

- 1080×1350 JPEG, 6장: 표지 1 · 본문 4 · 마무리 1
- 색: 크림 `#fff9f0` · 잉크 `#2a2623` · 주황 `#b5482b` · 살구 `#f6dfcd`, 표지 어두운 바탕 `#1d1a17`
- 글꼴: SUIT(제목·본문), 나눔고딕코딩(프롬프트). 둘 다 SIL Open Font License, 라이선스는 `fonts/`
- 견본: `preview/01.jpg`~`06.jpg` (`example/deck.json`을 렌더한 결과)

## 만드는 순서

1. 작업 폴더 `work/brand/ai/outbox/pending/<ID>/` 안에 `shots/`를 만들고 캡처를 넣는다. 실제로 해 보며 찍은 화면만 쓴다.
2. `deck.json`을 쓴다. `example/deck.json`을 복사해서 고치는 게 가장 빠르다.
3. 강조할 곳이 있으면 격자 그림을 만든다.
   `node /opt/data/work/brand/ai/templates/render.js --grid <작업폴더>/shots/02.png`
   → `/tmp/grid-02.jpg`를 보고 `[x0, y0, x1, y1]`을 % 로 적는다(왼쪽 위가 0, 오른쪽 아래가 100).
4. 렌더한다.
   `node /opt/data/work/brand/ai/templates/render.js <작업폴더>`
   - 통과(종료 코드 0): `slides/01.jpg`~, `meta.json`의 `slides`(장별 제목·본문), `render.json`
   - 실패(종료 코드 1): `slides/`는 건드리지 않고 이유를 `render.json`과 화면에 남긴다. 실패한 그림은 `/tmp/render-preview-<번호>/`에서 볼 수 있다.
5. 캡션·출처·meta 나머지를 채우고 `python3 /opt/data/scripts/check_card.py <작업폴더>`

렌더기는 `meta.json`에 두 가지를 쓴다. `slides`(장별 `kind`·제목·본문, 그림과 같은 글)는 덮어쓰고, `tested`는 `deck.json`의 값으로 맞춘다(날짜는 `YYYY-MM-DD`). `content_id`, `guide_url` 같은 다른 칸은 건드리지 않는다.

## deck.json

공통 칸

| 칸 | 뜻 | 예 |
|---|---|---|
| `no` | 자료실 번호, 세 자리 | `"001"` |
| `topic` | 주제 이름, 12자 안 | `"회의록"` |
| `tested` | 직접 해 본 날짜·기기·앱·플랜(그림 아래 줄과 `meta.tested`에 같이 쓰임) | `{"date": "2026-10-29", "device": "휴대폰 앱", "app": "…", "plan": "무료"}` |
| `masks` | 가릴 곳(선택), 캡처별 % 사각형 목록 | `{"shots/01.png": [[21, 27, 34, 30]]}` |
| `slides` | 장 목록(아래) | |

장 종류

| type | 쓰는 곳 | 칸 |
|---|---|---|
| `cover` | 1장 | `bg` 캡처, `lines` 크림 자막 1~2줄(상황), `hit` 주황 자막 1줄(해결), `pos` `"mid"`/`"lower"`, `tone` `"dark"`/`"light"`, `bg_pos` 배경 위치 `"50% 30%"`, `cue` 아래 문구(기본 '실제 화면으로 따라 하기') |
| `step` | 따라 하기 단계 | `step` 번호, `title` 최대 2줄, `em` 주황으로 칠할 말, `desc` 최대 2줄, `shot` 캡처, `mark` 강조 `[x0, y0, x1, y1]`, `focus` 보여 줄 높이 0~100(선택), `path` 누르는 순서 최대 4개 |
| `prompt` | 프롬프트 | `step`, `title`(`\n`로 줄바꿈), `em`, `prompt` 본문(`[바꿀 곳]`은 주황 표시), `hint`, `more` |
| `result` | 결과 화면 | `step`, `title`, `desc`, `shot`, `mark` |
| `end` | 마지막 장 | `lines` 큰 글 1~3줄, `dm` DM으로 받는 것. '아무 댓글이나 남기면'은 고정 문구 |

프롬프트가 길면 프롬프트 글씨를 35px에서 28px까지 자동으로 줄인다(경고로 알림). 그래도 넘치면 실패로 막는다.
화면 틀은 `mark` 가운데가 보이도록 캡처를 자동으로 올리고 내린다. `mark`가 없으면 화면 위쪽을 보여 준다. 가로로 긴 PC 캡처는 틀 안에 통째로 들어간다.

## 렌더기가 막는 것

- 자막·버튼 글이 한 줄을 넘음, 제목·설명이 정한 줄 수를 넘음
- 글자가 좌우 72px 밖(프로필 격자 3:4에서 잘림), 장 밖으로 나간 요소
- 글이 길어 화면 틀이 작아짐(단계 400px, 결과 460px 미만), 아래 출처 줄과 겹침
- 캡처·글꼴을 못 읽음, 작업 폴더 밖 파일, 이모지(글꼴에 없음)
- 6장이 아니면 경고만 한다. 최종 판정은 `check_card.py`

## 사람이 지키는 것(렌더기가 못 잡음)

- 표지 배경은 그 게시물 캡처 중 하나를 다시 쓴다. 표지용 그림을 따로 만들지 않는다.
- 크림 줄은 상황, 주황 줄은 해결. 표지는 세게, 본문은 정확하게.
- 보여 줄 곳이 화면 위쪽이면 `pos: "lower"`, 하얀 문서 화면이면 `tone: "light"`.
- 사람 이름·이메일·전화번호·회사명이 보이면 `masks`로 가린다. 원본 캡처는 그대로 두고 렌더에서만 가린다.
- 다른 서비스 로고를 크게 쓰지 않는다. 유명인 사진과 남의 이미지는 쓰지 않는다.
- `example/shots`는 예시 화면이다. 게시물에 쓰지 않는다.
- 댓글 안내는 '아무 댓글'이다. 키워드를 정하지 않는다(대표 결정 2026-10-30).

## 환경과 점검

- 크로미움: Hermes 공식 이미지에 든 것을 쓴다(`/opt/hermes/tools`, 실행 파일 경로는 `/etc/hermes/chromium-executable-path`).
- Playwright: 이미지에 Node용 모듈이 없어서 `/opt/data/tools`에 따로 설치했다. 크로미움 1208(Chrome 145)과 짝인 `playwright-core@1.58.2`.
  설치(서버, 관리자): `npm install --prefix /opt/data/tools --no-audit --no-fund playwright-core@1.58.2`
- 점검: `node /opt/data/work/brand/ai/templates/render.js --selftest` → '자체 시험 통과'가 나오면 된다.
- Hermes 이미지를 올린 뒤에는 자체 시험부터 돌린다. 크로미움 번호가 바뀌어 실패하면 짝이 맞는 playwright-core로 다시 설치한다.

## 바뀐 기록

- v0 (2026-10-30): 첫 확정. 표지 화면 자막형 + 본문 자료실형, 댓글 안내 '아무 댓글'.
- 렌더기 1.1 (2026-10-30): Hermes 이미지의 크로미움 경로 파일을 먼저 읽음, 환경 안내 보강.
- 렌더기 1.2 (2026-10-30): `meta.slides`에 check_card.py가 읽는 `kind` 추가(프롬프트 장 180자 기준), `deck.tested`를 `meta.tested`에 맞춰 씀, 긴 프롬프트는 글씨를 28px까지 자동으로 줄임.

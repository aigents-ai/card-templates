# 디자인 v0.1 — 인스타 AI 계정(@aigents_ai) 카드뉴스

대표 확정: 디자인 2026-10-30(표지 **화면 자막형**, 본문·마무리 **자료실형**), 제작 방식 2026-10-30(**화면 모음 + 실제 실행**).
이 폴더는 원본이다. 직원은 고치지 않고, 고칠 점은 '개선 후보'로 비서실장에게 올린다.

## 한눈에

- 1080×1350 JPEG 6장: 표지 1 · 본문 4 · 마무리 1
- 앱을 누르는 화면은 **화면 모음**(대표가 한 번 찍어 둔 실제 화면)에서 고른다. 매 편 새로 찍지 않는다.
- 결과는 **실제 실행**: `ask.py`가 프롬프트를 ChatGPT 기본 모델과 Claude에 그대로 보내고, 답 원문을 남긴다. 장에는 그 원문을 손대지 않고 보여 준다.
- 색: 크림 `#fff9f0` · 잉크 `#2a2623` · 주황 `#b5482b` · 살구 `#f6dfcd`, 표지 어두운 바탕 `#1d1a17`
- 글꼴: SUIT(제목·본문), 나눔고딕코딩(프롬프트). 둘 다 SIL Open Font License, 라이선스는 `fonts/`
- 견본: `preview/01.jpg`~`06.jpg` (`example/`을 렌더한 결과. example 의 화면·답은 예시라 게시물에 쓰지 않는다)

## 만드는 순서

작업 폴더는 `work/brand/ai/outbox/pending/<ID>/`. 도구 경로는 `T=/opt/data/work/brand/ai/templates`.

1. **prompt.txt** — 독자가 실제로 붙여 넣을 글을 그대로 쓴다. 예시 메모·자료가 필요하면 지어낸 내용으로 채우고, 사람 이름 대신 직함(팀장·디자이너)을 쓴다.
2. **실행** — `python3 $T/ask.py <작업폴더>` → `runs/gpt.md`, `runs/claude.md`, `runs/runs.json`
   - 같은 prompt.txt 로 이미 받은 답은 다시 부르지 않는다. prompt.txt 를 고치면 다시 받는다(`--force`로 강제).
3. **확인** — 두 답을 읽는다. 기대와 다르면 prompt.txt 를 고쳐 2로 돌아간다. 답 원문은 고치지 않는다.
4. **deck.json** — 화면은 화면 모음(`lib:`)에서 고른다. 맞는 화면이 없으면 '화면 필요: 무엇'으로 막힘 보고한다. 결과 장은 `answer`(아래 표).
5. **렌더** — `node $T/render.js <작업폴더>` → `slides/01.jpg`~, `meta.json`(slides·tested), `render.json`
   - 실패하면 `slides/`는 그대로 두고 이유를 남긴다. 실패한 그림은 `/tmp/render-preview-<번호>/`.
6. **검사** — 캡션·출처·meta 나머지를 채우고 `python3 /opt/data/scripts/check_card.py <작업폴더>`

렌더기는 `meta.json`에 두 가지를 쓴다. `slides`(장별 `kind`·제목·본문)는 덮어쓰고, `tested`는 실행 결과(또는 deck.tested)로 맞춘다. 다른 칸은 건드리지 않는다.

## 화면 모음 (`work/brand/ai/library/`)

- 대표가 찍은 앱 화면을 넣어 두는 곳. 이름은 `<앱>-<기기>/<번호>-<무엇>.jpg` (예: `chatgpt-phone/02-new-chat.jpg`)
- 등록: `node $T/render.js --import <원본> chatgpt-phone/02-new-chat --app "ChatGPT 앱" --device 휴대폰 --date 2026-10-30 --note "새 채팅 버튼"`
  → JPEG로 저장하고 `index.json`에 앱·기기·촬영일을 적는다. 장 아래 줄에 이 촬영일이 그대로 나온다.
- 사람 이름·메일·계정 사진이 보이면 `index.json`의 그 화면 `masks`에 `[x0, y0, x1, y1]`(%)을 적는다. 그 화면을 쓰는 모든 장에서 가려진다. 위치는 `--grid`로 확인.
- 앱 화면이 바뀌면 같은 이름으로 다시 등록한다(촬영일이 갱신된다).

## deck.json

공통 칸

| 칸 | 뜻 | 예 |
|---|---|---|
| `no` | 자료실 번호, 세 자리 | `"001"` |
| `topic` | 주제 이름, 12자 안 | `"회의록"` |
| `tested` | (선택) 직접 해 본 날짜·기기·앱·플랜. 비우면 실행 결과로 채운다 | `{"date": "2026-10-30", "device": "휴대폰 앱"}` |
| `masks` | (선택) 이 편에서만 가릴 곳 | `{"shots/01.png": [[21, 27, 34, 30]]}` |
| `slides` | 장 목록(아래) | |

장 종류

| type | 쓰는 곳 | 칸 |
|---|---|---|
| `cover` | 1장 | `bg` 배경(`"@gpt"` = 실제 답, 또는 `lib:…`·`shots/…`), `lines` 크림 자막 1~2줄(상황), `hit` 주황 자막 1줄(해결), `pos` `"mid"`/`"lower"`, `tone` `"dark"`/`"light"`, `bg_pos` `"50% 30%"`(그림 배경일 때), `cue` |
| `step` | 따라 하기 단계 | `step` 번호, `title` 최대 2줄, `em` 주황으로 칠할 말, `desc` 최대 2줄, `shot` 화면(`lib:…` 또는 `shots/…`), `mark` 강조 `[x0, y0, x1, y1]`(%), `focus`, `path` 최대 4개 |
| `prompt` | 프롬프트 | `step`, `title`(`\n` 줄바꿈), `em`, `prompt`(`[바꿀 곳]`은 주황 표시), `hint`, `more` |
| `answer` | 실제 답 | `step`, `title`, `desc`, `run`(`"gpt"`/`"claude"`), `mark` 강조할 **답 속 글 그대로**(예: `"견적서 작성"` → 그 글이 든 표·목록·문단에 테두리), `also` 같이 확인한 실행(예: `["claude"]`) |
| `result` | (예외) 직접 찍은 결과 화면 | `step`, `title`, `desc`, `shot`, `mark` |
| `end` | 마지막 장 | `lines` 큰 글 1~3줄, `dm` DM으로 받는 것. '아무 댓글이나 남기면'은 고정 문구 |

프롬프트 장에 보이는 글(바꿀 곳 `[ ]` 줄 빼고)은 실제로 돌린 prompt.txt 안에 그대로 있어야 한다.
프롬프트가 길면 글씨를 35px에서 28px까지 자동으로 줄인다(경고로 알림). 그래도 넘치면 실패로 막는다.
캡처 틀은 `mark` 가운데가 보이도록 화면을 자동으로 올리고 내린다. 답 틀은 `mark` 글이 든 덩어리를 가운데에 둔다.

## 실행 키와 비용

- 키: `OPENROUTER_API_KEY` — `/opt/data/profiles/insta-ai/ask.env`에 둔다(권한 600). Hermes 가 읽는 `.env`가 아니라서 Hermes 가 이 키로 다른 일을 하지 않는다. 월 사용 한도를 걸어 둔 키만 쓴다.
- 모델: `models.json` (`gpt` = ChatGPT 기본 모델, `claude` = Claude). ChatGPT 기본 모델이 바뀌면 여기만 고친다.
- 비용: 실행마다 `runs/runs.json`에 토큰·비용이 남는다.

## 렌더기가 막는 것

- 자막·버튼 글이 한 줄을 넘음, 제목·설명이 정한 줄 수를 넘음, 장 아래 줄이 한 줄을 넘음
- 글자가 좌우 72px 밖(프로필 격자 3:4에서 잘림), 장 밖으로 나간 요소, 화면 틀이 너무 작아짐, 아래 줄과 겹침
- 화면 모음에 등록되지 않은 화면, 작업 폴더·화면 모음 밖 파일, 캡처·글꼴을 못 읽음, 이모지
- 실행 결과가 없거나, 실행 뒤에 prompt.txt 가 바뀌었거나, 프롬프트 장 글이 prompt.txt 와 다름
- 답 속에 없는 `mark` 글, 실행하지 않은 `also`
- 6장이 아니면 경고만 한다. 최종 판정은 `check_card.py`

## 사람이 지키는 것(렌더기가 못 잡음)

- 답 원문(`runs/*.md`)은 고치지 않는다. 마음에 안 들면 prompt.txt 를 고쳐 다시 실행한다.
- '○○에서도 확인'은 실제로 실행해서 비슷한 결과를 본 경우에만(`also`).
- 화면 모음에는 대표가 실제로 찍은 화면만 넣는다. 화면을 만들어 내지 않는다.
- 크림 줄은 상황, 주황 줄은 해결. 표지는 세게, 본문은 정확하게.
- 다른 서비스 로고를 크게 쓰지 않는다. 유명인 사진과 남의 이미지는 쓰지 않는다.
- 댓글 안내는 '아무 댓글'. 키워드를 정하지 않는다.

## 환경과 점검

- 크로미움: Hermes 공식 이미지에 든 것(`/opt/hermes/tools`, 경로는 `/etc/hermes/chromium-executable-path`)
- Playwright: `/opt/data/tools`의 `playwright-core@1.58.2`(크로미움 1208과 짝). 설치(서버, 관리자): `npm install --prefix /opt/data/tools --no-audit --no-fund playwright-core@1.58.2`
- 점검: `node $T/render.js --selftest` → '자체 시험 통과'
- Hermes 이미지를 올린 뒤에는 자체 시험부터 돌린다.

## 바뀐 기록

- v0 (2026-10-30): 첫 확정. 표지 화면 자막형 + 본문 자료실형, 댓글 안내 '아무 댓글'.
- 렌더기 1.1~1.2 (2026-10-30): 크로미움 경로, check_card.py 의 `kind`, `meta.tested`, 긴 프롬프트 자동 축소.
- v0.1 · 렌더기 2.0 (2026-10-30): 화면 모음(`lib:`, `--import`, 화면별 가리기), 실제 답 장(`answer`), 실행 도구 `ask.py`·`models.json`, 표지 배경 `@실행`, 실행 결과와 프롬프트 일치 검사.
